<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2014 Osclass
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

osc_enqueue_script('admin-sweetalert');
osc_enqueue_script('admin-bs_selectpicker');
osc_enqueue_script('admin-tooltip');
osc_enqueue_script('admin-osc');

function customPageTitle($string) {
    return sprintf(__('Languages &raquo; %s'), $string);
}

function addHelp() {
    echo '<p>' . __("Add, edit or delete the language in which your Osclass is displayed, both the part that's viewable by users and the admin panel.") . '</p>';
}

function customPageHeader() {
    _e('Settings');
}

function customHead() {
    ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('body').on('click', '#import-language', function() {
                var _this = $(this);
                var language = $('#imported-language option:selected').val();

                _this.attr('disabled', true)
                    .parents('.modal-content')
                    .find('.modal-body')
                    .addClass('languages-preloading');

                $.ajax({
                    type: 'POST',
                    url: "<?php echo osc_admin_base_url(true) . "?page=ajax&action=import_language&" . osc_csrf_token_url(); ?>",
                    data: {'type' : 'import', 'language' : language},
                    success: function(res){
                        var ret = JSON.parse(res);

                        setTimeout(function() {
                            $.notify({
                                icon: "add_alert",
                                message: ret.msg
                            }, {
                                type: ret.status,
                                newest_on_top: true,
                                spacing: 30,
                                delay: 500,
                                timer: 2000,
                            });

                            if(ret.status == 'success') {
                                setTimeout(function() {
                                    location.href = location.href;
                                }, 3000);
                            } else {
                                _this.attr('disabled', false)
                                    .parents('.modal-content')
                                    .find('.modal-body')
                                    .removeClass('languages-preloading');
                            }
                        }, 2000);
                    }
                });
            });

            $('body').on('click', '#update-language', function() {
                var _this = $(this);
                var language = _this.attr('data-language-id');

                _this.attr('disabled', true)
                    .parents('.modal-content')
                    .find('.modal-body')
                    .addClass('languages-preloading');

                $.ajax({
                    type: 'POST',
                    url: "<?php echo osc_admin_base_url(true) . "?page=ajax&action=import_language&" . osc_csrf_token_url(); ?>",
                    data: {'type' : 'update', 'language' : language},
                    success: function(res){
                        var ret = JSON.parse(res);

                        setTimeout(function() {
                            $.notify({
                                icon: "add_alert",
                                message: ret.msg
                            }, {
                                type: ret.status,
                                newest_on_top: true,
                                spacing: 30,
                                delay: 500,
                                timer: 2000,
                            });

                            if(ret.status == 'success') {
                                setTimeout(function() {
                                    location.reload();
                                }, 3000);
                            } else {
                                _this.attr('disabled', false)
                                    .parents('.modal-content')
                                    .find('.modal-body')
                                    .removeClass('languages-preloading');
                            }
                        }, 2000);
                    }
                });
            });

            $('body').on('click', 'a.modal-update-language', function() {
                var _this = $(this);
                var language = _this.attr('data-language-id');

                $('#updateLanguageModal .modal-body').addClass('languages-preloading');

                $.getJSON(
                    "<?php echo osc_admin_base_url(true); ?>?page=ajax&action=get_market_product&<?php echo osc_csrf_token_url(); ?>",
                    {"type" : "language", "id" : language},
                    function(data){
                        $('#updated-language-name').text(data.name);
                        $('#updated-language-version').text(data.version);
                        $('#update-language').attr('data-language-id', language);

                        $('#updateLanguageModal .modal-body').removeClass('languages-preloading');
                    }
                );
            });

            // check_all bulkactions
            $("#check_all").change(function() {
                var isChecked = $(this).prop("checked");
                $('.col-bulkactions input').each( function() {
                    if( isChecked == 1 ) {
                        this.checked = true;
                    } else {
                        this.checked = false;
                    }
                });
            });
        });
    </script>
    <?php
}

osc_add_filter('admin_title', 'customPageTitle');
osc_add_hook('help_box','addHelp');
osc_add_hook('admin_page_header','customPageHeader');
osc_add_hook('admin_header','customHead', 10);

/* Header Menu */
$header_menu  = '<a id="help" href="javascript:;" class="btn btn-info btn-fab"><i class="material-icons md-24">error_outline</i></a>';
$header_menu .= '<a href="javascript:;" class="btn btn-rose" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#importLanguageModal"><i class="material-icons md-18 mr-1">cloud_upload</i> ' . __('Import language') . '</a>';
$header_menu .= '<a href="' . osc_admin_base_url(true) . '?page=languages&amp;action=add" class="btn btn-success"><i class="material-icons md-18">add</i> ' . __('Add language') . '</a>';

$iDisplayLength = __get('iDisplayLength');
$aData          = __get('aLanguages');
?>
<?php osc_current_admin_theme_path('parts/header.php'); ?>

<style>
    .languages-preloading {
        background: #fff url('<?php echo osc_current_admin_theme_url(); ?>img/category-preloader.gif') no-repeat center center;
        width: 100%;
        min-height: 115px;
    }
    .languages-preloading #import_language_form,
    .languages-preloading #update_language_form {
        display: none;
    }
</style>

<div class="row no-gutters">
    <div class="col-md-12 text-center text-md-right"><?php echo $header_menu; ?></div>
</div>

<div class="row no-gutters">
    <div class="col-md-5 col-xl-3 text-center text-md-left">
        <form class="form-inline" method="post"  style="display: inline!important;" action="<?php echo osc_admin_base_url(true); ?>">
            <div class="form-group no-gutters">
                <div class="col-12">
                    <?php osc_print_bulk_actions('bulk-actions', '', __get('bulk_options'), 'selectpicker show-tick', 'data-size="15" data-width="fit" data-style="btn btn-info btn-sm"'); ?>
                    <input id="bulk-actions-btn" type="button" data-bulk-type="languages" class="btn btn-info btn-sm" value="<?php echo osc_esc_html( __('Apply') ); ?>">
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="updateLanguageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php _e('Update Language'); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    <i class="material-icons">clear</i>
                </button>
            </div>

            <div class="modal-body">
                <form method="post" action="<?php echo osc_admin_base_url(true); ?>" id="update_language_form" class="has-form-actions">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td><?php _e('Language'); ?>:</td>
                            <td id="updated-language-name"></td>
                        </tr>

                        <tr>
                            <td><?php _e('Language Version'); ?>:</td>
                            <td id="updated-language-version"></td>
                        </tr>
                        </tbody>
                    </table>
                </form>
            </div>

            <div class="modal-footer">
                <button id="update-language" type="button" class="btn btn-info btn-link"><?php echo osc_esc_html( __('Update language') ); ?></button>
                <button type="button" data-dismiss="modal" class="btn btn-link"><?php _e('Cancel'); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="importLanguageModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php _e('Import New Language'); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    <i class="material-icons">clear</i>
                </button>
            </div>

            <div class="modal-body">
                <form method="post" action="<?php echo osc_admin_base_url(true); ?>" id="import_language_form" class="has-form-actions">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <label class="col-md-2 col-form-label text-left text-sm-right" for="country"><?php _e('Language'); ?></label>

                                <div class="col-md-10">
                                    <div class="form-group">
                                        <select id="imported-language" class="selectpicker show-tick" data-size="7" data-width="100%" data-style="btn btn-info btn-sm" name="language">
                                            <option value=""><?php _e('Choose a language'); ?></option>
                                            <?php $languages = osc_get_languages_list_api(); ?>

                                            <?php foreach($languages as $language): ?>
                                                <option value="<?php echo $language['language_code']; ?>"><?php echo $language['name']; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button id="import-language" type="button" class="btn btn-info btn-link"><?php echo osc_esc_html( __('Import language') ); ?></button>
                <button type="button" data-dismiss="modal" class="btn btn-link"><?php _e('Cancel'); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">public</i>
        </div>
        <h4 class="card-title"><?php _e('Manage Languages'); ?></h4>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <form id="bulk-actions-form" class="form-inline" method="post"  style="display: inline!important;" action="<?php echo osc_admin_base_url(true); ?>">
                <input type="hidden" name="page" value="languages" />
                <input id="bulk" type="hidden" name="action" value="" />

                <table class="table table-striped table-shopping">
                    <thead class="text-muted">
                    <th class="col-bulkactions">
                        <div class="form-check">
                            <label class="form-check-label">
                                <input id="check_all" class="form-check-input" type="checkbox" />
                                <span class="form-check-sign">
                                    <span class="check"></span>
                                </span>
                            </label>
                        </div>
                    </th>
                    <th><?php _e('Name'); ?></th>
                    <th><?php _e('Short name'); ?></th>
                    <th><?php _e('Description'); ?></th>
                    <th><?php _e('Enabled (website)'); ?></th>
                    <th><?php _e('Enabled (oc-admin)'); ?></th>
                    <th class="col-actions"><?php _e('Actions'); ?></th>
                    </thead>
                    <tbody>
                    <?php if( count($aData['aaData']) > 0 ) { ?>
                        <?php foreach($aData['aaData'] as $array) { ?>
                            <tr>
                                <?php foreach($array as $key => $value) { ?>
                                    <td <?php if(!$key) echo 'class="col-bulkactions"'; if($key == 6) echo 'class="col-actions"'; ?>><?php echo $value; ?></td>
                                <?php } ?>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="7" class="text-center">
                                <p><?php _e('No data available in table'); ?></p>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </form>

            <div class="row no-gutters">
                <div class="col-md-12">
                    <?php osc_show_pagination_admin($aData); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="item-delete-form" method="get" action="<?php echo osc_admin_base_url(true); ?>">
    <input type="hidden" name="page" value="languages" />
    <input type="hidden" name="action" value="delete" />
    <input type="hidden" name="id[]" value="" />
</form>

<?php osc_current_admin_theme_path('parts/footer.php'); ?>