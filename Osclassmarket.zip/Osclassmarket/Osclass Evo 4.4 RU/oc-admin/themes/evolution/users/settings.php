<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2014 Osclass
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

osc_enqueue_script('admin-validate');
osc_enqueue_script('admin-sweetalert');
osc_enqueue_script('admin-bs_selectpicker');
osc_enqueue_script('admin-osc');

function customPageTitle($string) {
    return sprintf(__('User Settings &raquo; %s'), $string);
}

function addHelp() {
    echo '<p>' . __("Manage the options related to users on your site. Here, you can decide if users must register or if email confirmation is necessary, among other options.") . '</p>';
}

function customPageHeader() {
    _e('Users');
}

//customize Head
function customHead() {
    ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('body').on('change', '#delete_inactive_users', function() {
                if($(this).is(':checked')) {
                    $('#delete_inactive_users_box').removeClass('fc-limited');
                } else {
                    $('#delete_inactive_users_box').addClass('fc-limited');
                }
            });

            $("#users-settings").validate({
                rules: {
                    delete_inactive_users_num_days: {
                        required: true,
                        digits: true
                    },
                    delete_inactive_users_num_items: {
                        required: true,
                        digits: true
                    }
                },
                messages: {
                    delete_inactive_users_num_days: {
                        required: '<?php echo osc_esc_js( __("Inactive days: this field is required")); ?>',
                        digits: '<?php echo osc_esc_js( __("Inactive days: this field must only contain numeric characters")); ?>'
                    },
                    delete_inactive_users_num_items: {
                        required: '<?php echo osc_esc_js( __("Published Listings: this field is required")); ?>',
                        digits: '<?php echo osc_esc_js( __("Published Listings: this field must only contain numeric characters")); ?>'
                    }
                },
                highlight: function(element) {
                    $(element).parents('.form-group').removeClass('has-success').addClass('has-danger');
                },
                success: function(element) {
                    $(element).parents('.form-group').removeClass('has-danger').addClass('has-success');
                },
                errorPlacement: function(error, element) {
                    $('.text-muted').prepend(error);
                }
            });
        });
    </script>
    <?php
}

osc_add_filter('admin_title', 'customPageTitle');
osc_add_hook('help_box','addHelp');
osc_add_hook('admin_page_header','customPageHeader');
osc_add_hook('admin_header','customHead', 10);

/* Header Menu */
$header_menu  = '<a id="help" href="javascript:;" class="btn btn-info btn-fab"><i class="material-icons md-24">error_outline</i></a>';
?>

<?php osc_current_admin_theme_path( 'parts/header.php' ); ?>

<div class="row no-gutters">
    <div class="col-md-12 text-right"><?php echo $header_menu; ?></div>
</div>

<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">settings</i>
        </div>
        <h4 class="card-title"><?php _e('User Settings'); ?></h4>
    </div>

    <div class="card-body">
        <form id="users-settings" action="<?php echo osc_admin_base_url(true); ?>" method="post" class="has-form-actions">
            <input type="hidden" name="page" value="users" />
            <input type="hidden" name="action" value="settings_post" />

            <div class="row no-gutters">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12 mt-2">
                            <fieldset>
                                <legend><?php _e('Settings'); ?></legend>

                                <div class="col-md-12 mb-2">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input id="enabled_users" class="form-check-input" type="checkbox" <?php echo (osc_users_enabled() ? 'checked' : ''); ?> name="enabled_users" value="1">
                                            <?php _e('Users enabled'); ?>

                                            <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-12 mb-2">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input id="enabled_user_registration" class="form-check-input" type="checkbox" <?php echo (osc_user_registration_enabled() ? 'checked' : ''); ?> name="enabled_user_registration" value="1">
                                            <?php _e('Anyone can register'); ?>

                                            <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-12 mb-2">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input id="enabled_user_online_status" class="form-check-input" type="checkbox" name="enabled_user_online_status" value="1" <?php echo (osc_user_online_status_enabled() ? 'checked' : ''); ?>> <?php _e('Show user\'s online status'); ?>
                                            <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                        </label>
                                    </div>

                                    <?php if(osc_user_online_status_enabled()): ?>
                                        <div class="mark rounded p-3 mb-2 w-100">
                                            <p><strong class="text-rose"><?php _e('Important!'); ?></strong> <?php _e('This feature was added since the Osclass Evolution v. 4.4.0 so if you want to show the user\'s online status on the ad page or on the public profile page add the following line of code in your template:'); ?></p>
                                            <code class="mb-3">
                                                <span class="php-tag">&lt;?php echo</span> <span class="php-function">osc_user_online_status();</span> <span class="php-tag">?&gt;</span>
                                            </code>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-12 mb-2">
                                    <label class="form-label text-left font-weight-normal"><?php _e('User\'s Account Validation'); ?></label>
                                    <select class="selectpicker show-tick w-100 w-xl-25" name="user_validation" data-dropup-auto="false" data-size="7" data-style="btn btn-info btn-sm">
                                        <option value=""><?php _e('Without Validation'); ?></option>
                                        <option value="admin_validation" <?php if(osc_user_validation_enabled() == 'admin_validation') echo 'selected'; ?>><?php _e('Admin Validation'); ?></option>
                                        <option value="email_validation" <?php if(osc_user_validation_enabled() == 'email_validation') echo 'selected'; ?>><?php _e('E-mail Validation'); ?></option>
                                    </select>
                                </div>

                                <div class="col-md-12 mb-2">
                                    <?php _e('Username blacklist'); ?>
                                    <input type="text" class="form-control w-50 w-xl-25 text-center d-inline" name="username_blacklist" value="<?php echo osc_esc_html(osc_username_blacklist()); ?>" />

                                    <span class="form-text text-muted"><?php _e('List of terms not allowed in usernames, separated by commas'); ?></span>
                                </div>
                            </fieldset>
                        </div>

                        <div class="col-md-12 mt-2">
                            <fieldset>
                                <legend><?php _e('Auto-delete inactive users'); ?></legend>

                                <div class="col-md-12 mb-2">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input id="delete_inactive_users" class="form-check-input" type="checkbox" <?php echo (osc_delete_inactive_users() ? 'checked' : ''); ?> name="delete_inactive_users" value="1">
                                            <?php _e('Delete inactive users'); ?>

                                            <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset id="delete_inactive_users_box" class="mb-3 <?php echo (osc_delete_inactive_users() ? '' : 'fc-limited'); ?>">
                                <div class="row no-gutters">
                                    <div class="col-md-12">
                                        <div class="form-group d-inline">
                                            <?php _e('Delete users who have not visited the site for more than:'); ?>
                                            <input type="text" class="form-control w-25 w-xl-5 text-center d-inline" name="delete_inactive_users_num_days" value="<?php echo osc_esc_html(osc_delete_inactive_users_num_days()); ?>" />
                                        </div>

                                        <div class="form-group d-inline">
                                            <?php _e('day(s) and have less than:'); ?>
                                            <input type="text" class="form-control w-25 w-xl-5 text-center d-inline" name="delete_inactive_users_num_items" value="<?php echo osc_esc_html(osc_delete_inactive_users_num_items()); ?>" />
                                            <?php _e('published listings'); ?>

                                            <span class="form-text text-muted"><?php _e('If the value is zero, it means that the option will be deactivated'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>

                        <div class="col-md-12 mt-2">
                            <fieldset>
                                <legend><?php _e('Admin notifications'); ?></legend>

                                <div class="col-md-12 mb-2">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input id="notify_new_user" class="form-check-input" type="checkbox" <?php echo (osc_notify_new_user() ? 'checked="checked"' : ''); ?> name="notify_new_user" value="1">
                                            <?php _e('When a new user is registered'); ?>

                                            <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                        </label>
                                    </div>
                                </div>
                            </fieldset>
                        </div>

                        <div class="col-md-12 mt-4">
                            <button type="submit" class="btn btn-info">
                                <?php echo osc_esc_html( __('Save changes') ); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php osc_current_admin_theme_path( 'parts/footer.php' ); ?>