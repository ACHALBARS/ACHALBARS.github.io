<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2014 Osclass
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

function addHelp() {
    echo '<p>' . __("Add, edit or delete the language in which your Osclass is displayed, both the part that's viewable by users and the admin panel.") . '</p>';
}
osc_add_hook('help_box','addHelp');

function customPageHeader(){ ?>
    <h1><?php _e('Settings'); ?>
        <a href="#" class="btn ico ico-32 ico-help float-right"></a>
        <a href="<?php echo osc_admin_base_url(true); ?>?page=languages&amp;action=add" class="btn btn-green ico ico-32 ico-add-white float-right" ><?php _e('Add language'); ?></a>
        <a id="b_import_languages" class="btn btn-blue mr-1 float-right" href="javascript:void(0);"><?php _e('Import Language'); ?></a>
    </h1>
    <?php
}
osc_add_hook('admin_page_header','customPageHeader');

function customPageTitle($string) {
    return sprintf(__('Languages &raquo; %s'), $string);
}
osc_add_filter('admin_title', 'customPageTitle');

//customize Head
function customHead() { ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('body').on('click', '#import-language', function() {
                var _this = $(this);
                var language = $('#imported-language option:selected').val();

                _this.attr('disabled', true)
                    .parents('form')
                    .addClass('languages-preloading');

                $.ajax({
                    type: 'POST',
                    url: "<?php echo osc_admin_base_url(true) . "?page=ajax&action=import_language&" . osc_csrf_token_url(); ?>",
                    data: {'type' : 'import', 'language' : language},
                    success: function(res){
                        var ret = JSON.parse(res);

                        setTimeout(function() {
                            $('#alerts').remove('.alert')
                                .html('<div id="flashmessage" class="alert mb-1 flashmessage flashmessage-ok" data-dismiss="alert" style="display: block;"><a class="btn ico btn-mini ico-close close">x</a>'+ ret.msg + '</div>');

                            if(ret.status == 'success') {
                                setTimeout(function() {
                                    location.href = location.href;
                                }, 3000);
                            } else {
                                $('#alerts').remove('.alert')
                                    .html('<div id="flashmessage" class="alert mb-1 flashmessage flashmessage-error" data-dismiss="alert" style="display: block;"><a class="btn ico btn-mini ico-close close">x</a>'+ ret.msg + '</div>');

                                _this.attr('disabled', false)
                                    .parents('form')
                                    .removeClass('languages-preloading');
                            }
                        }, 2000);
                    }
                });
            });

            // check_all bulkactions
            $("#check_all").change(function(){
                var isChecked = $(this).prop("checked");
                $('.col-bulkactions input').each( function() {
                    if( isChecked == 1 ) {
                        this.checked = true;
                    } else {
                        this.checked = false;
                    }
                });
            });

            // dialog delete
            $("#dialog-language-delete").dialog({
                autoOpen: false,
                modal: true,
                title: '<?php echo osc_esc_js( __('Delete language') ); ?>'
            });

            // dialog bulk actions
            $("#dialog-bulk-actions").dialog({
                autoOpen: false,
                modal: true
            });
            $("#bulk-actions-submit").click(function() {
                $("#datatablesForm").submit();
            });
            $("#bulk-actions-cancel").click(function() {
                $("#datatablesForm").attr('data-dialog-open', 'false');
                $('#dialog-bulk-actions').dialog('close');
            });
            // dialog bulk actions function
            $("#datatablesForm").submit(function() {
                if( $("#bulk_actions option:selected").val() == "" ) {
                    return false;
                }

                if( $("#datatablesForm").attr('data-dialog-open') == "true" ) {
                    return true;
                }

                $("#dialog-bulk-actions .form-row").html($("#bulk_actions option:selected").attr('data-dialog-content'));
                $("#bulk-actions-submit").html($("#bulk_actions option:selected").text());
                $("#datatablesForm").attr('data-dialog-open', 'true');
                $("#dialog-bulk-actions").dialog('open');
                return false;
            });
        });

        var importNewLanguageText  = '<?php echo osc_esc_js(__('Import new language')); ?>';

        // dialog delete function
        function delete_dialog(item_id) {
            $("#dialog-language-delete input[name='id[]']").attr('value', item_id);
            $("#dialog-language-delete").dialog('open');
            return false;
        }
    </script>
    <?php
}
osc_add_hook('admin_header','customHead', 10);

$iDisplayLength = __get('iDisplayLength');
$aData          = __get('aLanguages');

osc_current_admin_theme_path( 'parts/header.php' );
?>
    <style>
        .languages-preloading {
            background: #fff url('<?php echo osc_current_admin_theme_url(); ?>images/spinner_loading.gif') no-repeat center center !important;
            width: 100%;
            min-height: 50px;
        }
        .languages-preloading table,
        .languages-preloading .form-row {
            display: none;
        }
    </style>

    <!-- Form Import Language -->
    <div id="d_import_language" class="lightbox_country language has-form-actions hide">
        <form action="<?php echo osc_admin_base_url(true); ?>" method="post" accept-charset="utf-8" id="display-filters" class="form-horizontal import-language-form">
            <div id="alerts"></div>

            <div class="row-wrapper">
                <div class="form-row">
                    <div class="form-label"><?php _e('Country'); ?>:</div>

                    <div class="form-controls">
                        <select id="imported-language" name="language">
                            <option value=""><?php _e('Choose a language'); ?></option>
                            <?php $languages = osc_get_languages_list_api(); ?>

                            <?php foreach($languages as $language): ?>
                                <option value="<?php echo $language['language_code']; ?>"><?php echo $language['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <div class="wrapper">
                    <button class="btn btn-red close-dialog" ><?php _e('Cancel'); ?></button>
                    <button id="import-language" type="button" class="btn btn-submit" ><?php _e('Import language'); ?></button>
                </div>
            </div>
        </form>
    </div>
    <!-- End form import language -->

    <h2 class="render-title"><?php _e('Manage Languages'); ?> <a href="<?php echo osc_admin_base_url(true); ?>?page=languages&amp;action=add" class="btn btn-mini"><?php _e('Add new'); ?></a></h2>
    <div class="relative">
        <div id="language-toolbar" class="table-toolbar">
            <div class="float-right">

            </div>
        </div>
        <form class="" id="datatablesForm" action="<?php echo osc_admin_base_url(true); ?>" method="post" data-dialog-open="false">
            <input type="hidden" name="page" value="languages" />
            <div id="bulk-actions">
                <label>
                    <?php osc_print_bulk_actions('bulk_actions', 'action', __get('bulk_options'), 'select-box-extra'); ?>
                    <input type="submit" id="bulk_apply" class="btn" value="<?php echo osc_esc_html( __('Apply') ); ?>" />
                </label>
            </div>
            <div class="table-contains-actions">
                <table class="table" cellpadding="0" cellspacing="0">
                    <thead>
                    <tr>
                        <th class="col-bulkactions"><input id="check_all" type="checkbox" /></th>
                        <th><?php _e('Name'); ?></th>
                        <th><?php _e('Short name'); ?></th>
                        <th><?php _e('Description'); ?></th>
                        <th><?php _e('Enabled (website)'); ?></th>
                        <th><?php _e('Enabled (oc-admin)'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($aData['aaData'])>0) { ?>
                        <?php foreach( $aData['aaData'] as $array) { ?>
                            <tr>
                                <?php foreach($array as $key => $value) { ?>
                                    <?php if( $key==0 ) { ?>
                                        <td class="col-bulkactions">
                                    <?php } else { ?>
                                        <td>
                                    <?php } ?>
                                    <?php echo $value; ?>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="6" class="text-center">
                                <p><?php _e('No data available in table'); ?></p>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
                <div id="table-row-actions"></div> <!-- used for table actions -->
            </div>
        </form>
    </div>
<?php
osc_show_pagination_admin($aData);
?>
    <form id="dialog-language-delete" method="get" action="<?php echo osc_admin_base_url(true); ?>" class="has-form-actions hide">
        <input type="hidden" name="page" value="languages" />
        <input type="hidden" name="action" value="delete" />
        <input type="hidden" name="id[]" value="" />
        <div class="form-horizontal">
            <div class="form-row">
                <?php _e('Are you sure you want to delete this language?'); ?>
            </div>
            <div class="form-actions">
                <div class="wrapper">
                    <a class="btn" href="javascript:void(0);" onclick="$('#dialog-language-delete').dialog('close');"><?php _e('Cancel'); ?></a>
                    <input id="language-delete-submit" type="submit" value="<?php echo osc_esc_html( __('Delete') ); ?>" class="btn btn-red" />
                </div>
            </div>
        </div>
    </form>

    <div id="dialog-bulk-actions" title="<?php _e('Bulk actions'); ?>" class="has-form-actions hide">
        <div class="form-horizontal">
            <div class="form-row"></div>
            <div class="form-actions">
                <div class="wrapper">
                    <a id="bulk-actions-cancel" class="btn" href="javascript:void(0);"><?php _e('Cancel'); ?></a>
                    <a id="bulk-actions-submit" href="javascript:void(0);" class="btn btn-red" ><?php echo osc_esc_html( __('Delete') ); ?></a>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>

    <div id="market_installer" class="has-form-actions hide">
        <form action="" method="post" id="display-filters" class="form-horizontal import-language-form">
            <div id="alerts"></div>

            <div class="osc-modal-content-market">
                <table class="table" cellpadding="0" cellspacing="0">
                    <tbody>
                    <tr class="table-first-row">
                        <td><?php _e('Name'); ?></td>
                        <td><span id="market_name"><?php _e("Loading data"); ?></span></td>
                    </tr>
                    <tr class="even">
                        <td><?php _e('Version'); ?></td>
                        <td><span id="market_version"><?php _e("Loading data"); ?></span></td>
                    </tr>
                    </tbody>
                </table>
                <div class="clear"></div>
            </div>
            <div class="form-actions">
                <div class="wrapper">
                    <button id="market_cancel" class="btn btn-red" ><?php _e('Cancel'); ?></button>
                    <button id="update-language" class="btn btn-submit" ><?php _e('Update language'); ?></button>
                </div>
            </div>
        </form>
    </div>
    <script type="text/javascript">
        $(function() {
            $("#market_cancel").on("click", function(){
                $(".ui-dialog-content").dialog("close");
                return false;
            });
        });

        $('body').on('click', '#update-language', function() {
            var _this = $(this);
            var language = _this.attr('data-language-id');

            _this.attr('disabled', true)
                .parents('form')
                .addClass('languages-preloading');

            $.ajax({
                type: 'POST',
                url: "<?php echo osc_admin_base_url(true) . "?page=ajax&action=import_language&" . osc_csrf_token_url(); ?>",
                data: {'type' : 'update', 'language' : language},
                success: function(res){
                    var ret = JSON.parse(res);

                    setTimeout(function() {
                        $('#market_installer #alerts').remove('.alert')
                            .html('<div id="flashmessage" class="alert mb-1 flashmessage flashmessage-ok" data-dismiss="alert" style="display: block;"><a class="btn ico btn-mini ico-close close">x</a>'+ ret.msg + '</div>');

                        if(ret.status == 'success') {
                            setTimeout(function() {
                                location.reload();
                            }, 3000);
                        } else {
                            $('#market_installer #alerts').remove('.alert')
                                .html('<div id="flashmessage" class="alert mb-1 flashmessage flashmessage-error" data-dismiss="alert" style="display: block;"><a class="btn ico btn-mini ico-close close">x</a>'+ ret.msg + '</div>');

                            _this.attr('disabled', false)
                                .parents('form')
                                .removeClass('languages-preloading');
                        }
                    }, 2000);
                }
            });
        });

        $('.btn-market-popup').on('click',function() {
            var _this = $(this);
            var language = _this.attr('data-language-id');

            $('#market_installer form').addClass('languages-preloading');

            $.getJSON(
                "<?php echo osc_admin_base_url(true); ?>?page=ajax&action=get_market_product&<?php echo osc_csrf_token_url(); ?>",
                {"type" : "language", "id" : language},
                function(data){
                    $('#market_installer').dialog({
                        modal:true,
                        title: '<?php echo osc_esc_js( __('Update Language') ); ?>',
                        width: 485
                    });

                    $("#market_name").text(data.name);
                    $("#market_version").text(data.version);
                    $('#update-language').attr('data-language-id', language);

                    setTimeout(function() {
                        $('#market_installer form').removeClass('languages-preloading');
                    }, 2000);
                }
            );
        });
    </script>

<?php osc_current_admin_theme_path( 'parts/footer.php' ); ?>