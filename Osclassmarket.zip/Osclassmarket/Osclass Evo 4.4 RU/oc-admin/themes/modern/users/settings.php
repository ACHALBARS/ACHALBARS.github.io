<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2014 Osclass
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

osc_enqueue_script('jquery-validate');

function addHelp() {
    echo '<p>' . __("Manage the options related to users on your site. Here, you can decide if users must register or if email confirmation is necessary, among other options.") . '</p>';
}
osc_add_hook('help_box','addHelp');

osc_add_hook('admin_page_header','customPageHeader');
osc_add_hook('admin_header','customHead', 10);

function customPageHeader(){ ?>
    <h1><?php _e('Users'); ?>
        <a href="#" class="btn ico ico-32 ico-help float-right"></a>
    </h1>
    <?php
}

//customize Head
function customHead() {
    ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('body').on('change', '#delete_inactive_users', function() {
                if($(this).is(':checked')) {
                    $('#delete_inactive_users_box').show();
                } else {
                    $('#delete_inactive_users_box').hide();
                }
            });

            $("#users-settings").validate({
                rules: {
                    delete_inactive_users_num_days: {
                        required: true,
                        digits: true
                    },
                    delete_inactive_users_num_items: {
                        required: true,
                        digits: true
                    }
                },
                messages: {
                    delete_inactive_users_num_days: {
                        required: '<?php echo osc_esc_js( __("Inactive days: this field is required")); ?>',
                        digits: '<?php echo osc_esc_js( __("Inactive days: this field must only contain numeric characters")); ?>'
                    },
                    delete_inactive_users_num_items: {
                        required: '<?php echo osc_esc_js( __("Published Listings: this field is required")); ?>',
                        digits: '<?php echo osc_esc_js( __("Published Listings: this field must only contain numeric characters")); ?>'
                    }
                },
                wrapper: "li",
                errorLabelContainer: "#error_list",
                invalidHandler: function(form, validator) {
                    $('html,body').animate({ scrollTop: $('h1').offset().top }, { duration: 250, easing: 'swing'});
                },
                submitHandler: function(form){
                    $('button[type=submit], input[type=submit]').attr('disabled', 'disabled');
                    form.submit();
                }
            });
        });
    </script>
    <?php
}

function customPageTitle($string) {
    return sprintf(__('User Settings &raquo; %s'), $string);
}
osc_add_filter('admin_title', 'customPageTitle');

osc_current_admin_theme_path( 'parts/header.php' ); ?>
<!-- settings form -->
<h2 class="render-title"><?php _e('User Settings'); ?></h2>
<ul id="error_list"></ul>
<form id="users-settings" action="<?php echo osc_admin_base_url(true); ?>" method="post">
    <input type="hidden" name="page" value="users" />
    <input type="hidden" name="action" value="settings_post" />
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"> <?php _e('Settings'); ?></div>
                <div class="form-controls">
                    <label for="enabled_users" class="form-label-checkbox">
                        <input type="checkbox" id="enabled_users" name="enabled_users" <?php echo ( osc_users_enabled() ? 'checked="checked"' : '' ); ?> value="1" />
                        <?php _e('Users enabled'); ?>
                    </label>
                </div>
                <div class="form-controls separate-top-medium">
                    <label id="enabled_user_registration">
                        <input type="checkbox" name="enabled_user_registration" <?php echo ( osc_user_registration_enabled() ? 'checked="checked"' : '' ); ?> value="1" />
                        <?php _e('Anyone can register'); ?>
                    </label>
                </div>

                <div class="form-controls separate-top-medium">
                    <label id="enabled_user_online_status">
                        <input type="checkbox" <?php echo ( osc_user_online_status_enabled() ? 'checked="checked"' : '' ); ?> name="enabled_user_online_status" value="1" />
                        <?php _e('Show user\'s online status'); ?>
                    </label>
                </div>

                <?php if(osc_user_online_status_enabled()): ?>
                    <div class="form-row">
                        <div class="help-block">
                            <p><strong class="text-red"><?php _e('Important!'); ?></strong> <?php _e('This feature was added since the Osclass Evolution v. 4.4.0 so if you want to show the user\'s online status on the ad page or on the public profile page add the following line of code in your template:'); ?></p>

                            <div class="code-block">
                                <span class="php-tag">&lt;?php echo</span> <span class="php-function">osc_user_online_status();</span> <span class="php-tag">?&gt;</span>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="form-row separate-top-medium">
                    <div class="form-label"><?php _e('User\'s Account Validation'); ?></div>
                    <div class="form-controls">
                        <select name="user_validation">
                            <option value=""><?php _e('Without Validation'); ?></option>
                            <option value="admin_validation" <?php if(osc_user_validation_enabled() == 'admin_validation') echo 'selected'; ?>><?php _e('Admin Validation'); ?></option>
                            <option value="email_validation" <?php if(osc_user_validation_enabled() == 'email_validation') echo 'selected'; ?>><?php _e('E-mail Validation'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"> <?php _e('Auto-delete users'); ?></div>
                <div class="form-controls">
                    <label id="notify_new_user" class="form-label-checkbox">
                        <input type="checkbox" id="delete_inactive_users" name="delete_inactive_users" <?php echo ( osc_delete_inactive_users() ? 'checked="checked"' : '' ); ?> value="1" />
                        <?php _e('Delete inactive users'); ?>
                    </label>
                </div>

                <div id="delete_inactive_users_box" <?php echo ( osc_delete_inactive_users() ? '' : 'style="display:none;"' ); ?>>
                    <div class="form-row">
                        <div class="form-controls">
                            <?php _e('Delete users who have not visited the site for more than:'); ?>
                            <input type="text" class="input-small" name="delete_inactive_users_num_days" value="<?php echo osc_esc_html(osc_delete_inactive_users_num_days()); ?>" />
                            <?php _e('day(s) and have less than:'); ?>
                            <input type="text" class="input-small" name="delete_inactive_users_num_items" value="<?php echo osc_esc_html(osc_delete_inactive_users_num_items()); ?>" />
                            <?php _e('published listings'); ?>

                            <div class="help-box">
                                <?php _e('If the value is zero, it means that the option will be deactivated'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-label"> <?php _e('Admin notifications'); ?></div>
                <div class="form-controls">
                    <label id="notify_new_user" class="form-label-checkbox">
                        <input type="checkbox" id="notify_new_user" name="notify_new_user" <?php echo ( osc_notify_new_user() ? 'checked="checked"' : '' ); ?> value="1" />
                        <?php _e('When a new user is registered'); ?>
                    </label>
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"> <?php _e('Username blacklist'); ?></div>
                <div class="form-controls">
                    <label id="username_blacklist" class="form-label-input">
                        <input type="text" id="username_blacklist" name="username_blacklist" value="<?php echo osc_esc_html(osc_username_blacklist()); ?>" />
                        <span class="help-box"><?php _e('List of terms not allowed in usernames, separated by commas'); ?></span>
                    </label>
                </div>
            </div>
            <div class="form-actions">
                <input type="submit" id="save_changes" value="<?php echo osc_esc_html( __('Save changes') ); ?>" class="btn btn-submit" />
            </div>
        </div>
    </fieldset>
</form>
<!-- /settings form -->
<?php osc_current_admin_theme_path( 'parts/footer.php' ); ?>