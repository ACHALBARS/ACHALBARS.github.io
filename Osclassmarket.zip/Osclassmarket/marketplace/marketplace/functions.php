<?php define('MARKETPLACE_THEME_VERSION', '1.1.2');

if( !function_exists('logo_header') ) {
    function logo_header() {
        $html = '<img border="0" alt="' . osc_esc_html(osc_page_title()) . '" src="' . osc_current_web_theme_url('images/logo.png') . '" />';
        
        if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.png")) return $html;
        
        return osc_page_title();
    }
}


if(!function_exists('get_user_menu')) {

    function get_user_menu() {
        $options = array();
        $options[] = array(
    	'name' => __('Public Profile'), 
    	'url' => osc_user_public_profile_url(osc_logged_user_id()),
    	'class' => 's_kabnav-publ');
        $options[] = array(
            'name' => __('Listings'),
            'url' => osc_user_list_items_url(),
            'class' => 's_kabnav-adman'
        );
        $options[] = array(
            'name' => __('Account'),
            'url' => osc_user_profile_url(),
            'class' => 's_kabnav-edit'
        );
        $options[] = array(
            'name' => __('Logout'),
            'url' => osc_user_logout_url(),
            'class' => 's_kabnav-exit'
        );
        
        return $options;
    }
}

function marketplace_validation_wrapper() {
    echo '<h1></h1><ul id="error_list"></ul>';
}

if(!function_exists('marketplace_related_listings')) {
    function marketplace_related_listings() {
        View::newInstance()->_exportVariableToView('items', array());
        
        $num_ads = osc_get_preference('related_items_num', 'marketplace_theme');

        $mSearch = new Search();
        
        if(osc_get_preference('related_items_same_cats', 'marketplace_theme'))
            $mSearch->addCategory(osc_item_category_id());
        
        if(osc_get_preference('related_items_country', 'marketplace_theme'))
            $mSearch->addCountry(osc_item_country());
        
        if(osc_get_preference('related_items_region', 'marketplace_theme'))
            $mSearch->addRegion(osc_item_region());
            
        if(osc_get_preference('related_items_premium_only', 'marketplace_theme'))
            $mSearch->dao->where(sprintf("%st_item.b_premium = 1", DB_TABLE_PREFIX));
            
        if(osc_get_preference('related_items_pic_only', 'marketplace_theme'))
            $mSearch->withPicture(true);
            
        $mSearch->addItemConditions(sprintf("%st_item.pk_i_id < %s ", DB_TABLE_PREFIX, osc_item_id()));
        $mSearch->limit(0, $num_ads);

        $aItems      = $mSearch->doSearch();
        
        if(count($aItems)) {
            $global_items = View::newInstance()->_get('items');
            View::newInstance()->_exportVariableToView('items', $aItems);

            return count($aItems);
        }
        
        unset($mSearch);

        return 0;
    }
}

if( !function_exists('marketplace_item_title') ) {
    function marketplace_item_title() {
        $title = osc_item_title();
        
        foreach(osc_get_locales() as $locale) {
            if(Session::newInstance()->_getForm('title')) {
                $title_ = Session::newInstance()->_getForm('title');
                if(@$title_[$locale['pk_c_code']]){
                    $title = $title_[$locale['pk_c_code']];
                }
            }
        }
        
        return $title;
    }
}

if(!function_exists('marketplace_item_description')) {
    function marketplace_item_description() {
        $description = osc_item_description();
        
        foreach(osc_get_locales() as $locale) {
            if( Session::newInstance()->_getForm('description')) {
                $description_ = Session::newInstance()->_getForm('description');
                if(@$description_[$locale['pk_c_code']]){
                    $description = $description_[$locale['pk_c_code']];
                }
            }
        }
        
        return $description;
    }
}

function marketplace_user_type() {
    if(Params::getParam('sCompany') !== '' && Params::getParam('sCompany') != null) {
        Search::newInstance()->addJoinTable('pk_i_id', DB_TABLE_PREFIX . 't_user', DB_TABLE_PREFIX . 't_item.fk_i_user_id = ' . DB_TABLE_PREFIX . 't_user.pk_i_id', 'LEFT OUTER' ) ; 
    
        if(Params::getParam('sCompany') == 1)
            Search::newInstance()->addConditions(sprintf("%st_user.b_company = 1", DB_TABLE_PREFIX));
        
        else
            Search::newInstance()->addConditions(sprintf("coalesce(%st_user.b_company, 0) != 1", DB_TABLE_PREFIX, DB_TABLE_PREFIX));
    }
}

function marketplace_sidebar_category_search($catId = null) {
    $aCategories = array();
    
    if($catId == null) {
        $aCategories[] = Category::newInstance()->findRootCategoriesEnabled();
    } 
    else {
        $aCategories = Category::newInstance()->toRootTree($catId);
        end($aCategories);
        $cat = current($aCategories);

        $childCategories = Category::newInstance()->findSubcategoriesEnabled($cat['pk_i_id']);
        
        if(count($childCategories)) $aCategories[] = $childCategories;
    }

    if(!count($aCategories)) return "";

    marketplace_print_sidebar_category_search($aCategories, $catId);
}

function marketplace_print_sidebar_category_search($aCategories, $currentCategory = null, $i = 0) {
    if(!isset($aCategories[$i])) return null;
    osc_category_parent_id() ? $parentId = osc_category_parent_id() : $parentId = $currentCategory;
    
    $category = $aCategories[$i];
    $i++;
    
    if(!isset($category['pk_i_id'])) {
        //if($i == 1) echo '<li><a href="' . osc_esc_html(osc_update_search_url(array('sCategory' => null, 'iPage' => null))) . '">' . osc_esc_html(__('All categories', 'marketplace')) . ' <span>(' . CategoryStats::newInstance()->countItemsFromCategory($parentId) . ')</span></a></li>';
        
        foreach($category as $key => $value) {
            if(isset($currentCategory) && $currentCategory == $value['pk_i_id']) continue;
            
            echo '<li><a href="' . osc_esc_html(osc_update_search_url(array('sCategory' => $value['pk_i_id'], 'iPage' => null))) . '">' . $value['s_name'] . ' <span>(' . CategoryStats::newInstance()->countItemsFromCategory($value['pk_i_id']) . ')</span></a></li>';
        }
    }
    else {
        if($i == 1) echo '<li><a href="' . osc_esc_html(osc_update_search_url(array('sCategory' => null, 'iPage' => null))) . '">' . osc_esc_html(__('All categories', 'marketplace')) . ' <span>(' . CategoryStats::newInstance()->countItemsFromCategory($parentId) . ')</span></a></li>';
        
        if(isset($currentCategory) && $currentCategory != $category['pk_i_id'])
            echo '<li><a href="' . osc_esc_html(osc_update_search_url(array('sCategory' => $category['pk_i_id'], 'iPage' => null))) . '">' . $category['s_name'] . ' <span>(' . CategoryStats::newInstance()->countItemsFromCategory($category['pk_i_id']) . ')</span></a></li>';
        
        marketplace_print_sidebar_category_search($aCategories, $currentCategory, $i);
    }
}

function marketplace_categories_select($current = null) {
	$default = __('Select category...', 'marketplace');
    echo '<option value="">' . osc_esc_html(__($default, 'marketplace')) . '</option>';
    
    $categories = Category::newInstance()->toTree();
    
    foreach($categories as $category) {
        echo '<option value="' . $category['pk_i_id'] . '"' . (($category['pk_i_id'] == $current['pk_i_id']) ? 'selected="selected"' : '' ) . '>' . $category['s_name'] . '</option>';
        
        if(isset($category['categories']) && is_array($category['categories'])) {
            CategoryForm::subcategory_select($category['categories'], $current, $default, 2);
        }
    }
}

function marketplace_replace_number_to_x($number) {
    return substr($number,0,4) . str_repeat("X", (strlen($number) - 4));
}

function marketplace_mobile_number() {
    if (osc_item_id()) {
		$user = User::newInstance()->findByPrimaryKey(osc_item_user_id());
        
		if($user['s_phone_mobile']){
			if (osc_get_preference('item_hide_phone', 'marketplace_theme')) {
?>
                <script type="text/javascript">
                    $(document).ready(function () {
                        var number = '<?php echo $user['s_phone_mobile']; ?>';
                        $('.s_info-item__phone span').click(function () {
                            $(this).html(number);
                        });
                    });
                </script>
                <span title="<?php echo osc_esc_html(__('Click to show the number', 'marketplace')); ?>"><?php echo marketplace_replace_number_to_x($user['s_phone_mobile']); ?></span>
<?php
            } 
            else {
                echo $user['s_phone_mobile'];
            }
			
		}
    } 
    elseif(osc_user()) {
		if(osc_user_phone_mobile()){
			if (osc_get_preference('item_hide_phone', 'marketplace_theme')) {
?>
                <script type="text/javascript">
                    $(document).ready(function () {
                        var number = '<?php echo osc_user_phone_mobile(); ?>';
                        $('.s_info-item__phone span').click(function () {
                            $(this).html(number);
                        });
                    });
                </script>
                <span title="<?php echo osc_esc_html(__('Click to show the number', 'marketplace')); ?>"><?php echo marketplace_replace_number_to_x(osc_user_phone_mobile()); ?></span>
<?php
            } 
            else {
                echo osc_user_phone_mobile();
            }
		}
	}
}

function marketplace_phone_number() {
    if(osc_item_id()) {
		$user = User::newInstance()->findByPrimaryKey(osc_item_user_id());
		
        if($user['s_phone_land']){
			if(osc_get_preference('item_hide_phone', 'marketplace_theme')) {
?>
                <script type="text/javascript">
                    $(document).ready(function () {
                        var number = '<?php echo $user['s_phone_land']; ?>';
                        $('.s_info-item__phone span').click(function () {
                            $(this).html(number);
                        });
                    });
                </script>
                <span title="<?php echo osc_esc_html(__('Click to show the number', 'marketplace')); ?>"><?php echo marketplace_replace_number_to_x($user['s_phone_land']); ?></span>
                <?php
            } 
            else {
                echo $user['s_phone_land'];
            }	
        }
    } 
    elseif(osc_user()) {
	   if(osc_user_phone_land()) {
			if(osc_get_preference('item_hide_phone', 'marketplace_theme')) {
?>
                <script type="text/javascript">
                    $(document).ready(function () {
                        var number = '<?php echo osc_user_phone_land(); ?>';
                        $('.s_info-item__phone span').click(function () {
                            $(this).html(number);
                        });
                    });
                </script>
                <span title="<?php echo osc_esc_html(__('Click to show the number', 'marketplace')); ?>"><?php echo marketplace_replace_number_to_x(osc_user_phone_land()); ?></span>
<?php
            } 
            else {
                echo osc_user_phone_land();
            }	
        }
	}
}

function marketplace_region_select($class = '') {
    View::newInstance()->_exportVariableToView('list_regions', Search::newInstance()->listRegions('%%%%', '>=', 'region_name ASC') ) ;

    echo '<select id="sRegion" name="sRegion" class="selectpicker ' . $class . '" data-size="7">';
	echo '<option value="">' . __('Select a region...', 'marketplace') . '</option>';
    
    while( osc_has_list_regions() ) {
        echo '<option value="' . osc_list_region_id() . '">' . osc_list_region_name() . '</option>';
    }
    
    echo '</select>';

    View::newInstance()->_erase('list_regions');
}

function marketplace_region_select_items($class = '') {
 

    echo '<select id="sRegion" name="sRegion" class="selectpicker ' . $class . '" data-size="7">';
	echo '<option value="">' . __('Select a region...', 'marketplace') . '</option>';
    
    while( osc_has_list_regions() ) {
        echo '<option value="' . osc_list_region_id() . '">' . osc_list_region_name() . '</option>';
    }
    
    echo '</select>';

}

function marketplace_city_select($class = '') {
    View::newInstance()->_exportVariableToView('list_cities', Search::newInstance()->listCities('%%%%', '>=', 'city_name ASC') );
    
    echo '<select id="sCity" name="sCity" class="selectpicker ' . $class . '" data-size="7">' ;
    echo '<option value="">' . __('Select a city...', 'marketplace') . '</option>' ;
    
    while(osc_has_list_cities()) {
        echo '<option value="' . osc_esc_html(osc_list_city_name()) . '">' . osc_list_city_name() . '</option>' ;
    }
    
    echo '</select>';
    
    View::newInstance()->_erase('list_cities');;
}

function marketplace_city_select_items($class = '') {

    
    echo '<select id="sCity" name="sCity" class="selectpicker ' . $class . '" data-size="7">' ;
    echo '<option value="">' . __('Select a city...', 'marketplace') . '</option>' ;
    
    while(osc_has_list_cities()) {
        echo '<option value="' . osc_esc_html(osc_list_city_name()) . '">' . osc_list_city_name() . '</option>' ;
    }
    
    echo '</select>';
    
}

function marketplace_country_select($class='') {
    View::newInstance()->_exportVariableToView('list_countries', Search::newInstance()->listCountries('>=', 'country_name ASC') ) ;

    echo '<select id="sCountry" name="sCountry" class="selectpicker '.$class.'">' ;
    echo '<option value="">' . __('Select a country...', 'marketplace') . '</option>';
    
    while( osc_has_list_countries() ) {
        echo '<option value="' . osc_esc_html(osc_list_country_name()) . '">' . osc_list_country_name() . '</option>' ;
    }
    
    echo '</select>';
    
    View::newInstance()->_erase('list_countries') ;
}

function marketplace_search_location($country = null, $region = null, $city = null, $address = null) {
	$sAddress = (isset($address) ? $address : '');
    $sCity = (isset($city) ? $city : '');
    $sRegion = (isset($region) ? $region : '');
    $sCountry = (isset($country) ? $country : '');
    $fulladdress = sprintf('%s, %s, %s, %s', $sAddress, $sCity, $sRegion, $sCountry);
	$key =  osc_get_preference('map_geo_key', 'marketplace_theme');
    
    $response = file_get_contents(sprintf('https://maps.googleapis.com/maps/api/geocode/json?address=%s&key=%s', urlencode($fulladdress), $key));
    $jsonResponse = json_decode($response);
    $coord = false;

    if (isset($jsonResponse->results[0]->geometry->location) && count($jsonResponse->results[0]->geometry->location)) {
        $location = $jsonResponse->results[0]->geometry->location;
        $coord['lat'] = $location->lat;
        $coord['lng'] = $location->lng;
    }
    
	return  $coord ;
}

function marketplace_category_url($category_id) {
    return osc_search_url(array('sCategory' => $category_id));
}

function marketplace_category_root($category_id) {
    $category = Category::newInstance()->findRootCategory($category_id);
    $cat_id = $category['pk_i_id'];
    
    return $cat_id;
}

function marketplace_category_root_name($category_id) {
    $category = Category::newInstance()->findRootCategory($category_id);
    $cat_name = $category['s_name'];
    
    return $cat_name;
}

function marketplace_most_popular($limit = 8){
	$order = Search::newInstance();
	$order->dao->select();
	$order->dao->from(DB_TABLE_PREFIX . 't_item i, '.DB_TABLE_PREFIX.'t_item_location l, '.DB_TABLE_PREFIX.'t_item_stats s');
	$order->dao->where('l.fk_i_item_id = i.pk_i_id AND s.fk_i_item_id = i.pk_i_id');
	$order->dao->where('i.b_enabled', 1);
	$order->dao->where('i.b_active', 1);
	$order->dao->where('i.b_spam', 0);
	$order->dao->where('dt_expiration >= CURDATE()');
	$order->dao->groupBy('s.fk_i_item_id');
	$order->dao->orderBy('SUM(s.i_num_views)', 'DESC');
    $order->dao->limit($limit);

    $result = $order->dao->get();

    if($result == false) return array();

    return Item::newInstance()->extendData($result->result());
	
}
// THEME ADMIN FUNCTIONS
function theme_marketplace_actions_admin() {
    if(Params::getParam('file') == 'oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php') {
        if(Params::getParam('donation') == 'successful') {
            osc_set_preference('donation', '1', 'marketplace_theme');
            osc_reset_preferences();
        }
    }

    if(Params::getParam('marketplace_general') == 'done') {
        $cat_icons = Params::getParam('cat_icons');
        
        osc_set_preference('logo_text', Params::getParam('logo_text'), 'marketplace_theme');
        osc_set_preference('cat_icons', ($cat_icons ? '1' : '0'), 'marketplace_theme');
        
        osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
        
        header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=basic')); exit;
    }

    switch(Params::getParam('action_specific')) {
        case('upload_logo'):
            $package = Params::getFiles('logo');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if(move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/logo.png")) {
                    osc_add_flash_ok_message(__('The logo image has been uploaded correctly', 'marketplace'), 'admin');
                } 
                else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } 
            else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }
            
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/header.php')); exit;
        break;
        
        case('remove'):
            if(file_exists( WebThemes::newInstance()->getCurrentThemePath() . "images/logo.png")) {
                @unlink( WebThemes::newInstance()->getCurrentThemePath() . "images/logo.png" );
                
                osc_add_flash_ok_message(__('The logo image has been removed', 'marketplace'), 'admin');
            } 
            else {
                osc_add_flash_error_message(__("Image not found", 'marketplace'), 'admin');
            }
            
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/header.php')); exit;
        break;
        
        case 'marketplace_basic_settings':
            osc_set_preference('keyword_placeholder', Params::getParam('keyword_placeholder'), 'marketplace_theme');
            osc_set_preference('default_show_items', Params::getParam('default_show_items'), 'marketplace_theme');
            osc_set_preference('item_icon', (Params::getParam('item_icon') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('subcategories', (Params::getParam('subcategories') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('main_search', Params::getParam('main_search'), 'marketplace_theme');
            osc_set_preference('categoriesmain', (Params::getParam('categoriesmain') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('categories_description', Params::getParam('categories_description'), 'marketplace_theme');
            osc_set_preference('main_carousel', Params::getParam('main_carousel'), 'marketplace_theme');
            osc_set_preference('main_carousel2', Params::getParam('main_carousel2'), 'marketplace_theme');
            osc_set_preference('carousel_num_ads', Params::getParam('carousel_num_ads'), 'marketplace_theme');
            osc_set_preference('lib_num_ads', Params::getParam('lib_num_ads'), 'marketplace_theme');
            osc_set_preference('main_brands_block_status', (Params::getParam('main_brands_block_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('main_map', (Params::getParam('main_map') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('map_style', Params::getParam('map_style'), 'marketplace_theme');
            osc_set_preference('map_api_key', Params::getParam('map_api_key'), 'marketplace_theme');
            osc_set_preference('map_geo_key', Params::getParam('map_geo_key'), 'marketplace_theme');
            osc_set_preference('map_num_ads', Params::getParam('map_num_ads'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=basic')); exit;
        break;
        
        case 'marketplace_main_top_text':
            osc_set_preference('h1_intro_text', Params::getParam('h1_intro_text'), 'marketplace_theme');
            osc_set_preference('h2_intro_text', Params::getParam('h2_intro_text'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main')); exit;
        break;
        
        case 'marketplace_upload_main_top_bg':
            $package = Params::getFiles('main_top_bg');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if( move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/bg-head.jpg" ) ) {
                    osc_add_flash_ok_message(__('The background image has been uploaded correctly', 'marketplace'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }
                
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main')); exit;
        break;
        
        case 'marketplace_main_middle_text':
            osc_set_preference('middle_block_status', (Params::getParam('middle_block_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('first_md_text', Params::getParam('first_md_text'), 'marketplace_theme');
            osc_set_preference('first_md_description', Params::getParam('first_md_description'), 'marketplace_theme');
            osc_set_preference('first_md_list', Params::getParam('first_md_list'), 'marketplace_theme');
            osc_set_preference('second_md_list', Params::getParam('second_md_list'), 'marketplace_theme');
            osc_set_preference('last_md_list', Params::getParam('last_md_list'), 'marketplace_theme');
            osc_set_preference('last_md_text', Params::getParam('last_md_text'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main')); exit;
        break;
        
        case 'marketplace_upload_main_middle_bg':
            $package = Params::getFiles('main_middle_bg');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if( move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/bg-whychoose.jpg" ) ) {
                    osc_add_flash_ok_message(__('The background image has been uploaded correctly', 'marketplace'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }
            
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main')); exit;
        break;
        
        case 'marketplace_main_bottom_text':
            osc_set_preference('bottom_block_status', (Params::getParam('bottom_block_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('h2_left_bm_text', Params::getParam('h2_left_bm_text'), 'marketplace_theme');
            osc_set_preference('subtitle_left_bm_text', Params::getParam('subtitle_left_bm_text'), 'marketplace_theme');
            osc_set_preference('h2_right_bm_text', Params::getParam('h2_right_bm_text'), 'marketplace_theme');
            osc_set_preference('subtitle_right_bm_text', Params::getParam('subtitle_right_bm_text'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main')); exit;
        break;
        
        case 'marketplace_upload_main_bottom_bg':
            $package = Params::getFiles('main_bottom_bg');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if( move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/bg-wwdev.jpg" ) ) {
                    osc_add_flash_ok_message(__('The background image has been uploaded correctly', 'marketplace'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }

            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/main.php&m=settings&l=main')); exit;
        break;
        
        case 'marketplace_footer_settings':
            osc_set_preference('ft_logo_status', (Params::getParam('ft_logo_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('ft_r_items_status', (Params::getParam('ft_r_items_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('ft_categories_status', (Params::getParam('ft_categories_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('ft_text', Params::getParam('ft_text'), 'marketplace_theme');
            osc_set_preference('ft_address', Params::getParam('ft_address'), 'marketplace_theme');
            osc_set_preference('ft_phone', Params::getParam('ft_phone'), 'marketplace_theme');
            osc_set_preference('ft_email', Params::getParam('ft_email'), 'marketplace_theme');
            osc_set_preference('ft_copyright', Params::getParam('ft_copyright'), 'marketplace_theme');
            osc_set_preference('ft_facebook', Params::getParam('ft_facebook'), 'marketplace_theme');
            osc_set_preference('ft_twitter', Params::getParam('ft_twitter'), 'marketplace_theme');
            osc_set_preference('ft_google', Params::getParam('ft_google'), 'marketplace_theme');
            osc_set_preference('ft_ln', Params::getParam('ft_ln'), 'marketplace_theme');
            osc_set_preference('ft_pinterest', Params::getParam('ft_pinterest'), 'marketplace_theme');
            osc_set_preference('ft_vk', Params::getParam('ft_vk'), 'marketplace_theme');
            osc_set_preference('ft_ok', Params::getParam('ft_ok'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/footer.php&m=settings&l=footer')); exit;
        break;
        
        case 'marketplace_upload_footer_logo':
            $package = Params::getFiles('footer_logo');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if( move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/bg-logo-white.png" ) ) {
                    osc_add_flash_ok_message(__('The footer logo has been uploaded correctly', 'marketplace'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }

            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/footer.php&m=settings&l=footer')); exit;
        break;
        
        case 'marketplace_category_icons':
            $category_id = Params::getParam('category_id');
            $package = Params::getFiles('category_icon');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if( move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . $category_id . ".png" ) ) {
                    osc_add_flash_ok_message(__('The icon has been uploaded correctly', 'marketplace'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }

            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/category-icons.php&m=settings&l=category')); exit;
        break;
        
        case 'marketplace_upload_favicon':
            $package = Params::getFiles('marketplace_favicon');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                $img = ImageResizer::fromFile($package['tmp_name']);
                $img_name = 'favicon.' . $img->getExt();
                $path = WebThemes::newInstance()->getCurrentThemePath() . 'images/' .$img_name ;
                $img->saveToFile($path);

                osc_set_preference('favicon', $img_name, 'marketplace_theme');
                osc_add_flash_ok_message(__('The favicon image has been uploaded correctly', 'marketplace'), 'admin');
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }

            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/favicon.php&m=settings&l=favicon')); exit;
        break;
        
        case 'marketplace_search_settings':
            osc_set_preference('search_country_field_status', (Params::getParam('search_country_field_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('search_position', Params::getParam('search_position'), 'marketplace_theme');
            osc_set_preference('search_premium_num_ads', Params::getParam('search_premium_num_ads'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/search.php&m=settings&l=search')); exit;
        break;
        
        case 'marketplace_color_settings':
            osc_set_preference('color_publish_item', Params::getParam('color_publish_item'), 'marketplace_theme');
            osc_set_preference('color_publish_item_hover', Params::getParam('color_publish_item_hover'), 'marketplace_theme');
            osc_set_preference('color_other_btns', Params::getParam('color_other_btns'), 'marketplace_theme');
            osc_set_preference('color_other_btns_hover', Params::getParam('color_other_btns_hover'), 'marketplace_theme');
            osc_set_preference('color_forms_bg_header', Params::getParam('color_forms_bg_header'), 'marketplace_theme');
            osc_set_preference('color_forms_font_header', Params::getParam('color_forms_font_header'), 'marketplace_theme');
            osc_set_preference('color_side_block_bg_header', Params::getParam('color_side_block_bg_header'), 'marketplace_theme');
            osc_set_preference('color_side_block_font_header', Params::getParam('color_side_block_font_header'), 'marketplace_theme');
            osc_set_preference('color_category_label_bg', Params::getParam('color_category_label_bg'), 'marketplace_theme');
            osc_set_preference('color_category_label_font', Params::getParam('color_category_label_font'), 'marketplace_theme');
            osc_set_preference('color_category_label_bg_hover', Params::getParam('color_category_label_bg_hover'), 'marketplace_theme');
            osc_set_preference('color_category_label_font_hover', Params::getParam('color_category_label_font_hover'), 'marketplace_theme');
            osc_set_preference('color_prem_item_label_bg', Params::getParam('color_prem_item_label_bg'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/colors.php&m=settings&l=colors')); exit;
        break;
        
        case 'marketplace_items_settings':
            osc_set_preference('item_location', (Params::getParam('item_location') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('item_countries', (Params::getParam('item_countries') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('item_fields_position', Params::getParam('item_fields_position'), 'marketplace_theme');
            osc_set_preference('item_hide_phone', (Params::getParam('item_hide_phone') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('item_mark', (Params::getParam('item_mark') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('item_google_map', (Params::getParam('item_google_map') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('item_useful_info_status', (Params::getParam('item_useful_info_status') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('item_useful_info_text', Params::getParam('item_useful_info_text'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/items.php&m=settings&l=items')); exit;
        break;
        
        case 'marketplace_related_items_settings':
            osc_set_preference('related_items_num', Params::getParam('related_items_num'), 'marketplace_theme');
            osc_set_preference('related_items_premium_only', (Params::getParam('related_items_premium_only') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('related_items_pic_only', (Params::getParam('related_items_pic_only') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('related_items_same_cats', (Params::getParam('related_items_same_cats') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('related_items_country', (Params::getParam('related_items_country') ? '1' : '0'), 'marketplace_theme');
            osc_set_preference('related_items_region', (Params::getParam('related_items_region') ? '1' : '0'), 'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/related-items.php&m=settings&l=related')); exit;
        break;
        
        case 'marketplace_ads':
		osc_set_preference('ads_hp_un_categories',         trim(Params::getParam('ads_hp_un_categories', false, false, false)),                  'marketplace_theme');
		osc_set_preference('ads_hp_top_latest_items',         trim(Params::getParam('ads_hp_top_latest_items', false, false, false)),                  'marketplace_theme');
        osc_set_preference('ads_hp_un_latest_items',         trim(Params::getParam('ads_hp_un_latest_items', false, false, false)),                  'marketplace_theme');
        osc_set_preference('ads_sp_top',         trim(Params::getParam('ads_sp_top', false, false, false)),                  'marketplace_theme');
        osc_set_preference('ads_sp_un',         trim(Params::getParam('ads_sp_un', false, false, false)),                  'marketplace_theme');
        osc_set_preference('ads_ip_un_desc',         trim(Params::getParam('ads_ip_un_desc', false, false, false)),                  'marketplace_theme');
        osc_set_preference('ads_ip_un_info',         trim(Params::getParam('ads_ip_un_info', false, false, false)),                  'marketplace_theme');
        osc_set_preference('ads_ip_sidebar',         trim(Params::getParam('ads_ip_sidebar', false, false, false)),                  'marketplace_theme');
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/ads.php&m=ads')); exit;
        break;
        
        case 'marketplace_brands_logo':
            $brand_id = Params::getParam('brand_id');
            $package = Params::getFiles('brand_image');
            
            if($package['error'] == UPLOAD_ERR_OK) {
                if( move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/partner" . $brand_id . ".jpg" ) ) {
                    osc_add_flash_ok_message(__('The logo has been uploaded correctly', 'marketplace'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'marketplace'), 'admin');
            }
            
            osc_add_flash_ok_message(__('Theme settings updated correctly', 'marketplace'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands')); exit;
        break;
    }
}

if(function_exists('osc_admin_menu_appearance')) {
    osc_admin_menu_appearance(__('Header logo', 'marketplace'), osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/header.php'), 'header_marketplace');
    osc_admin_menu_appearance(__('Theme settings', 'marketplace'), osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=basic'), 'settings_marketplace');
} 
else {
    function marketplace_admin_menu() {
        echo '<h3><a href="#">' . __('Marketplace theme', 'marketplace') . '</a></h3>
            <ul>
                <li><a href="' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/header.php') . '">&raquo; ' . __('Header logo', 'marketplace') . '</a></li>
                <li><a href="' . osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php') . '">&raquo; ' . __('Theme settings', 'marketplace') . '</a></li>
		   </ul>';
    }

    osc_add_hook('admin_menu', 'marketplace_admin_menu');
}

if(!function_exists('marketplace_theme_install')) {
    function marketplace_theme_install() {
        osc_set_preference('version', MARKETPLACE_THEME_VERSION, 'marketplace_theme');
        osc_set_preference('footer_link', '1', 'marketplace_theme');
        osc_set_preference('donation', '0', 'marketplace_theme');
        osc_set_preference('default_logo', '1', 'marketplace_theme');
        
        osc_set_preference('keyword_placeholder', __('ie. car', 'marketplace'), 'marketplace_theme');
        osc_set_preference('default_show_items', 'gallery', 'marketplace_theme');
        osc_set_preference('item_icon', '1', 'marketplace_theme');
        osc_set_preference('subcategories', '1', 'marketplace_theme');
        osc_set_preference('main_search', 'inc.searchcitybyreg', 'marketplace_theme');
        osc_set_preference('categoriesmain', '1', 'marketplace_theme');
        osc_set_preference('categories_description', 'top', 'marketplace_theme');
        osc_set_preference('main_carousel', 'premium', 'marketplace_theme');
        osc_set_preference('main_carousel2', 'popular', 'marketplace_theme');
        osc_set_preference('carousel_num_ads', '8', 'marketplace_theme');
        osc_set_preference('lib_num_ads', '8', 'marketplace_theme'); 
        osc_set_preference('main_brands_block_status', '1', 'marketplace_theme');
        osc_set_preference('main_map', '0', 'marketplace_theme');
        osc_set_preference('map_style', 'marketplace', 'marketplace_theme');
        osc_set_preference('map_num_ads', '10', 'marketplace_theme');
        
        osc_set_preference('h1_intro_text', __('World`s Largest Marketplace', 'marketplace'), 'marketplace_theme');
        osc_set_preference('h2_intro_text', __('You Can Buy, Sell Anything You Can Think Of.', 'marketplace'), 'marketplace_theme');
        
        osc_set_preference('middle_block_status', '1', 'marketplace_theme');
        osc_set_preference('first_md_text', __('Why choose Marketplace', 'marketplace'), 'marketplace_theme');
        osc_set_preference('first_md_description', __('Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet repellat laborum, quis, vero aspernatur cumque quia', 'marketplace'), 'marketplace_theme');
        osc_set_preference('first_md_list', __('Sell Your Item Safely', 'marketplace'), 'marketplace_theme');
        osc_set_preference('second_md_list', __('Meet buyer at a safe location', 'marketplace'), 'marketplace_theme');
        osc_set_preference('last_md_list', __('Pass the item only after payment', 'marketplace'), 'marketplace_theme');
        osc_set_preference('last_md_text', __('Are you ready to start safe selling in Marketplace ?', 'marketplace'), 'marketplace_theme');
        
        osc_set_preference('bottom_block_status', '1', 'marketplace_theme');
        osc_set_preference('h2_left_bm_text', __('Thousands of people will see your item', 'marketplace'), 'marketplace_theme');
        osc_set_preference('subtitle_left_bm_text', __('Just post a new listing, describe the product, upload photos and specify a price', 'marketplace'), 'marketplace_theme');
        osc_set_preference('h2_right_bm_text', __('Are you looking for something special ?', 'marketplace'), 'marketplace_theme');
        osc_set_preference('subtitle_right_bm_text', __('Thousands of sellers offer their best products, just use the search on the site', 'marketplace'), 'marketplace_theme');
        
        osc_set_preference('ft_logo_status', '1', 'marketplace_theme');
        osc_set_preference('ft_r_items_status', '1', 'marketplace_theme');
        osc_set_preference('ft_categories_status', '1', 'marketplace_theme');
        osc_set_preference('ft_text', __('Lorem ipsum dolor sit amet, consectetur adipisicing elit. consectetur adipisicing elit. Ad quidem minus repellat. Distinctio, reiciendis, esse!', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_address', __('Your City, Region and Address', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_phone', __('+1-555-2222-33', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_email', __('info@yourdomain.com', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_copyright', __('© All rights reserved. MarketPlace', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_facebook', __('https://www.facebook.com/', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_twitter', __('https://twitter.com/', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_google', __('https://instagram.com/', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_ln', __('https://linkedin.com', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_pinterest', __('https://www.pinterest.com', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_vk', __('https://vk.com', 'marketplace'), 'marketplace_theme');
        osc_set_preference('ft_ok', __('https://ok.ru', 'marketplace'), 'marketplace_theme');
        
        osc_set_preference('search_country_field_status', '0', 'marketplace_theme');
        osc_set_preference('search_position', 'right', 'marketplace_theme');
        osc_set_preference('search_premium_num_ads', '4', 'marketplace_theme');
        
        osc_set_preference('color_publish_item', '#00c550', 'marketplace_theme');
        osc_set_preference('color_publish_item_hover', '#00953c', 'marketplace_theme');
        osc_set_preference('color_other_btns', '#00c550', 'marketplace_theme');
        osc_set_preference('color_other_btns_hover', '#00953c', 'marketplace_theme');
        osc_set_preference('color_forms_bg_header', '#1f183f', 'marketplace_theme');
        osc_set_preference('color_forms_font_header', '#ffffff', 'marketplace_theme');
        osc_set_preference('color_side_block_bg_header', '#1f183f', 'marketplace_theme');
        osc_set_preference('color_side_block_font_header', '#ffffff', 'marketplace_theme');
        osc_set_preference('color_category_label_bg', '#eeeeee', 'marketplace_theme');
        osc_set_preference('color_category_label_font', '#0f0a28', 'marketplace_theme');
        osc_set_preference('color_category_label_bg_hover', '#e6e6e6', 'marketplace_theme');
        osc_set_preference('color_category_label_font_hover', '#0f0a28', 'marketplace_theme');
        osc_set_preference('color_prem_item_label_bg', '#00c550', 'marketplace_theme');
        
        osc_set_preference('item_location', '1', 'marketplace_theme');
        osc_set_preference('item_countries', '0', 'marketplace_theme');
        osc_set_preference('item_fields_position', 'bottom', 'marketplace_theme');
        osc_set_preference('item_hide_phone', '1', 'marketplace_theme');
        osc_set_preference('item_mark', '1', 'marketplace_theme');
        osc_set_preference('item_google_map', '0', 'marketplace_theme');
        osc_set_preference('item_useful_info_status', '1', 'marketplace_theme');
        osc_set_preference('item_useful_info_text', __('Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur, libero sed cum. Delectus suscipit tempore fugit, accusamus inventore, sunt quod ullam saepe consequuntur quasi illo odit, reprehenderit dolorum tempora nisi.', 'marketplace'), 'marketplace_theme');
        
        osc_set_preference('related_items_num', '3', 'marketplace_theme');
        osc_set_preference('related_items_premium_only', '0', 'marketplace_theme');
        osc_set_preference('related_items_pic_only', '0', 'marketplace_theme');
        osc_set_preference('related_items_same_cats', '0', 'marketplace_theme');
        osc_set_preference('related_items_country', '0', 'marketplace_theme');
        osc_set_preference('related_items_region', '0', 'marketplace_theme');
        
        osc_reset_preferences();
    }
}

if(!function_exists('check_install_marketplace_theme')) {
    function check_install_marketplace_theme() {
        $current_version = osc_get_preference('version', 'marketplace_theme');
        //check if current version is installed or need an update
        if(!$current_version) {
            marketplace_theme_install();
        }
    }
}

function marketplace_delete() {
    Preference::newInstance()->delete(array('s_section' => 'marketplace_theme'));
}

check_install_marketplace_theme();

osc_add_hook('init_admin', 'theme_marketplace_actions_admin');
osc_add_hook('theme_delete_marketplace', 'marketplace_delete');
osc_add_hook('search_conditions', 'marketplace_user_type');

function marketplace_custom_false_404() {   
    if (!Search::newInstance()->count()) header('HTTP/1.1 200 Ok');
}

osc_add_hook("after_search", "marketplace_custom_false_404" );

function marketplace_country_id() {
	$aCountries = Country::newInstance()->listAll();
	if (count($aCountries) >= 0){
		foreach($aCountries as $country){
			$countryID = $country['pk_c_code'];
			}
		}
	return $countryID;
	}
	
if (!function_exists('marketplace_user_country_code')) {	
function marketplace_user_country_code() {
        return (string) osc_user_field("fk_c_country_code");
    }
}
?>