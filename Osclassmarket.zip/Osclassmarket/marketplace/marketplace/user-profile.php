<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        <?php UserForm::location_javascript(); ?>
        
        <main class="m_box c_main c_kabinet c_kabinet-edit">
        	<div class="m_inb">
        		<div class="c_cont">
        
        			<div class="c_reg">
        				<div class="c_form c_reg-form">
        					<form action="<?php echo osc_base_url(true); ?>" method="post">
                                <input type="hidden" name="page" value="user" />
                                <input type="hidden" name="action" value="profile_post" />
        						<div class="c_form-label c_single-form__upload">
        							<div class="c_form-upload__label">
        								<label for="c_form-upload__inp">
        									<span class="c_form-thumb"></span>
        								</label>
        							</div>
        						</div>
        
        						<div class="c_form-label c_single-form__name">
        							<?php UserForm::name_text(osc_user()); ?>
        							<span class="c_form-placeholder <?php if(osc_logged_user_name()) echo 'active'; ?>"><?php _e('Name', 'marketplace') ?>*</span>
        						</div>
        						<div class="c_form-label c_single-form__email">
        							<input id="s_email" type="email" name="s_email" value="<?php echo osc_user_email(); ?>">
        							<label for="email" class="c_form-placeholder <?php if(osc_user_email()) echo 'active'; ?>"><?php _e('E-mail', 'marketplace') ?>*</label>
        						</div>
        						<div class="c_form-label c_single-form__pass">
        							<input type="password" name="s_password">
        							<label for="password" class="c_form-placeholder"><?php _e('Password', 'marketplace') ?>*</label>
        						</div>
        						<div class="c_form-label c_single-form__phone">
        							<?php UserForm::phone_land_text(osc_user()); ?>
        							<span class="c_form-placeholder <?php if(osc_user_phone_land()) echo 'active'; ?>"><?php _e('Mobile phone', 'marketplace') ?></span>
        						</div>
        
        						<div class="c_form-label c_select s_search-select c_single-form__name">
        			                 <?php UserForm::is_company_select(osc_user()); ?>
        						</div>
        						<div class="c_form-label c_select s_search-select c_single-form__location">
        			                 <?php UserForm::region_select(osc_get_regions(), osc_user()); ?>
        						</div>
        						<div class="c_form-label c_select s_search-select c_single-form__location">
        							<?php UserForm::city_select(osc_get_cities(), osc_user()); ?>
        						</div>
        						<div class="c_form-label c_single-form__location">
        							<?php UserForm::address_text(osc_user()); ?>
        							<span class="c_form-placeholder <?php if(osc_user_address()) echo 'active'; ?>"><?php _e('Address', 'marketplace') ?></span>
        						</div>
        						<div class="c_form-label inp-counter">
        							<?php UserForm::multilanguage_info(__get('locales'), osc_user()); ?>
        							<span class="c_form-placeholder <?php if(osc_user_info()) echo 'active'; ?>"></span>
        						</div>
        						<?php osc_run_hook('user_profile_form', osc_user()); ?>
        						<div class="c_reg-btn c_save-btn centerbutton">
									<button type="submit"><i class="mp mp-r"></i><?php _e('Save', 'marketplace') ?></button>
        						</div>
								  <?php osc_run_hook('user_form'); ?>
        					</form>
        				</div>
        			</div>
        		</div>
        
        		<aside class="c_side">
        
        			<div class="s_box s_kabnav">
        				<ul>
        					<?php echo osc_private_user_menu(get_user_menu()); ?>
        				</ul>
        			</div>
        
        		</aside>
        	</div>
        </main><!-- .main -->
        <script>            
            $('#regionId').change(function() {
                $('select#cityId').selectpicker('val', '').trigger('change');
                setTimeout(function(){$('select#cityId').selectpicker('refresh');}, 500);
            });
        </script>
        <style>.c_form-label:before{background-image: none!important;}</style>
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>