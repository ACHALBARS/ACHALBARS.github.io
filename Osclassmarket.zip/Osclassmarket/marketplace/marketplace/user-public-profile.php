<?php 
$location_array = array();
if(trim(osc_user_city()." ".osc_user_zip())) {
    $location_array[] = trim(osc_user_city()." ".osc_user_zip());
}
if(osc_user_region()) {
    $location_array[] = osc_user_region();
}
if(osc_user_country()) {
    $location_array[] = osc_user_country();
}
if(osc_user_address()) {
    if(osc_user_city_area()) {
        $location_array[] = osc_user_address().", ".osc_user_city_area();
    } else {
        $location_array[] = osc_user_address();
    }
}
$location = implode(", ", $location_array);
unset($location_array);
?>
<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <main class="m_box c_main c_profile">
        	<div class="m_inb">
        		<div class="c_cont">
        
        			<div class="c_single-box c_profile-user">
        				<div class="s_box-dark s_user-whois">
        					<div class="s_user-thumb"></div>
        					<div class="s_user-ident">
        						<div class="s_user-ident__name"><?php echo osc_user_name(); ?></div>
        						<div class="s_user-ident__posit">
                                    <?php if(osc_user_is_company()) _e('Company', 'marketplace'); else _e('User', 'marketplace'); ?>
                                </div>
        					</div>
        				</div>
        				<div class="c_profile-contact">
                            <?php if(osc_user_phone_mobile()): ?>
        					   <a href="#" class="s_info-item s_info-item__phone"><?php marketplace_mobile_number(); ?></a>
                            <?php endif; ?>
                            
                            <?php if(osc_user_phone_land()): ?>
                                <a href="#" class="s_info-item s_info-item__phone"><?php marketplace_phone_number(); ?></a>
                            <?php endif; ?>
                            
                            <?php if($location): ?>
        					   <div class="s_info-item s_info-item__adres"><?php echo $location; ?></div>
                            <?php endif; ?>
                            
        					<div class="s_info-item s_info-item__calend"><?php echo osc_format_date(osc_user()['dt_reg_date']); ?></div>
        				</div>
        			</div>			
                    
                    <?php if(osc_user_info()): ?>
            			<div class="c_single-box c_single-desc">
            				<div class="c_single-head">Description</div>
            				<div class="c_txt">
            					<?php echo osc_user_info(); ?>
            				</div>
            			</div>
                    <?php endif; ?>
                    
                    <?php if(osc_count_items()):?>
            			<div class="c_related">
            				<div class="c_related-head"><?php _e('Latest Listings', 'marketplace'); ?></div>
            				
                            <div class="c_list">
                                <?php while(osc_has_items()): ?>
                                    <div class="c_item">
                    					<div class="c_item-thumb">
                                            <?php if(osc_images_enabled_at_items() && osc_count_item_resources()): ?>
                        					   <div class="c_item-photo"><img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="<?php echo osc_highlight(osc_item_title()); ?>"></div>
                                            <?php else: ?>
                                                <div class="c_item-photo"><img style="min-height: auto;" src="<?php echo osc_current_web_theme_url('images/no_photo.gif') ; ?>" alt="<?php _e('No Photo', 'marketplace') ?>"></div>
                                            <?php endif; ?>
                                            
                                            <?php if(osc_item_is_premium()): ?>
                                                <div class="c_item-favorite"></div>
                                            <?php endif; ?>
                    					</div>
                    					<div class="c_item-info">
                                            <div class="c_item-ins">
                        						<a href="<?php echo osc_item_url() ; ?>" class="c_item-title">
                                                     <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_highlight(osc_item_title()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_title()); ?>
                                                </a>
                                                
                        						<div class="c_item-desc">
                                                    <?php if(strlen(osc_item_description()) > 25) echo mb_substr(osc_highlight(osc_item_description()), 0, 23,'UTF-8') . '...'; else echo osc_highlight(osc_item_description()); ?>
                                                </div>
                                                
                        						<a href="<?php echo marketplace_category_url(marketplace_category_root(osc_item_category_id())); ?>" class="c_item-cat <?php if(osc_get_preference('item_icon', 'marketplace_theme')): ?>cat-with-icon<?php endif; ?>">
                                                    <?php if(osc_get_preference('item_icon', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/cat-ico-" . marketplace_category_root(osc_item_category_id()) . ".png")): ?>
                                                        <img border="0" style="position: relative;top: -5px;max-width: 40px;float: left;margin-right: 5px;" src="<?php echo osc_current_web_theme_url('images/cat-ico-' . marketplace_category_root(osc_item_category_id()) . '.png');?>" />
                                                    <?php endif; ?>
                                                    <?php echo marketplace_category_root_name(osc_item_category_id()); ?>
                                                </a>
                                                <div class="c_item-photos"><?php echo osc_count_item_resources(); ?></div>
                        						<a href="<?php echo osc_item_url() ; ?>" class="c_item-view"><?php _e('View item', 'marketplace') ?></a>
                                            </div>
                    					</div>
                    					<div class="c_item-addit">
                                            <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
                                                <div class="c_item-price"><?php echo osc_item_formated_price(); ?></div>
                                            <?php endif; ?>
                                            
                    						<a href="<?php echo osc_item_url() ; ?>" class="c_item-more"><?php _e('Learn more', 'marketplace') ?></a>
                                            <div class="c_item-location"><?php echo osc_item_city(); ?></div>
                    					</div>
                    				</div>
                                <?php endwhile; ?>
                                
                                <?php if(osc_list_total_pages() > 1): ?>
                                   <div class="pagination">
                                       <?php echo osc_pagination_items(); ?>
                                   </div>
                               <?php endif; ?>
                            </div>
            			</div>		
                    <?php endif; ?>
        		</div>
                <?php if((osc_reg_user_can_contact() && osc_is_web_user_logged_in() || !osc_reg_user_can_contact()) && (osc_logged_user_id() != osc_user_id())): ?>
            		<aside class="c_side">
            			<div class="s_box s_contact">
            				<div class="s_contact-head"><?php _e('Contact publisher', 'marketplace'); ?></div>
            				<div class="c_form s_contact-form">
            					<form id="contact_form" action="<?php echo osc_base_url(true); ?>"  role="form" method="post" name="contact_form">
                                    <input type="hidden" name="action" value="contact_post" />
                                    <input type="hidden" name="page" value="user" />
                                    <input type="hidden" name="id" value="<?php echo osc_user_id();?>" />
                                                
            						<div class="c_form-label c_single-form__user">
            							<input id="yourName" type="text" name="yourName">
            							<span class="c_form-placeholder"><?php _e('Your name', 'marketplace'); ?></span>
            						</div>
            						<div class="c_form-label c_single-form__email">
            							<input id="yourEmail" type="email" name="yourEmail">
            							<span class="c_form-placeholder"><?php _e('Your e-mail', 'marketplace'); ?></span>
            						</div>
            						<div class="c_form-label c_single-form__phone">
            							<input id="phoneNumber" type="tel" name="phoneNumber">
            							<span class="c_form-placeholder"><?php _e('Your phone', 'marketplace'); ?></span>
            						</div>
            						<div class="c_form-label c_single-form__mess c_single-form__area">
            							<textarea id="message" name="message"></textarea>
            							<span class="c_form-placeholder"><?php _e('Comment', 'marketplace'); ?></span>
            						</div>
                                    
                                    <?php osc_run_hook('item_contact_form', osc_item_id()); ?>
									<div class="inp-captcha">
                                    <?php osc_show_recaptcha(); ?>
                                    </div>
            						<input type="submit" value="<?php _e('Send', 'marketplace'); ?>">
            					</form>
            				</div>
            			</div>
            		</aside>
                <?php endif; ?>
        	</div>
        </main><!-- .main -->
        
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>