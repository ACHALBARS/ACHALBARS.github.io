<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body>
        <?php osc_current_web_theme_path('header.php'); ?>
        
        <div class="c_reg">
        	<div class="c_reg-top">
        		<div class="c_reg-head"><?php _e('Login', 'marketplace') ?></div>
        		<?php _e('Welcome back! We have been missing you, a lot!', 'marketplace') ?>
        	</div>
        	<div class="c_form c_reg-form">
        		<form action="<?php echo osc_base_url(true); ?>" method="post">
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="login_post" />
                    
        			<div class="c_form-label c_single-form__email">
        				<input id="email" type="email" name="email">
        				<label for="email" class="c_form-placeholder"><?php _e('E-mail', 'marketplace') ?>*</label>
        			</div>
        			<div class="c_form-label c_single-form__pass">
        				<input id="password" type="password" name="password">
        				<label for="password" class="c_form-placeholder"><?php _e('Password', 'marketplace') ?>*</label>
        			</div>
        			<div class="c_reg-forgot">
        				<a href="<?php echo osc_recover_user_password_url(); ?>"><?php _e('Forgot password?', 'marketplace') ?></a>
        				<div class="c_reg-forgot__remember">
        					<label for="remember">
                                <input id="remember" type="checkbox" name="remember" value="1" checked>
        						<span class="c_reg-forgot__label"><?php _e('Remember me', 'marketplace') ?></span>
        					</label>
        				</div>
        			</div>
        			<div class="c_reg-btn">
						<button type="submit"><i class="mp mp-r"></i><?php _e('Log in', 'marketplace') ?></button>
        			</div>
        			<div class="c_reg-link">
        				<a href="<?php echo osc_register_account_url(); ?>"><?php _e('Register for a free account', 'marketplace') ?></a>
        			</div>
        		</form>
        	</div>
        </div>

        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>