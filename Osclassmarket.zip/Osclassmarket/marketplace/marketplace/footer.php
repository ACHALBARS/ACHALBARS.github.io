<div class="m_box c_botwidg">
	<div class="m_inb">
        <?php if(count(Widget::newInstance()->findByLocation('footer1'))): ?>
            <?php $widget_1 = Widget::newInstance()->findByLocation('footer1'); ?>
    		
            <div class="c_botwidg-item">
    			<div class="c_botwidg-item__title"><?php echo $widget_1[0]['s_description']; ?></div>
    			<?php echo $widget_1[0]['s_content']; ?>
    		</div>
        <?php endif; ?>
        
		<?php if(count(Widget::newInstance()->findByLocation('footer2'))): ?>
            <?php $widget_2 = Widget::newInstance()->findByLocation('footer2'); ?>
    		
            <div class="c_botwidg-item">
    			<div class="c_botwidg-item__title"><?php echo $widget_2[0]['s_description']; ?></div>
    			<?php echo $widget_2[0]['s_content']; ?>
    		</div>
        <?php endif; ?>
        
        <?php if(count(Widget::newInstance()->findByLocation('footer3'))): ?>
            <?php $widget_3 = Widget::newInstance()->findByLocation('footer3'); ?>
    		
            <div class="c_botwidg-item">
    			<div class="c_botwidg-item__title"><?php echo $widget_3[0]['s_description']; ?></div>
    			<?php echo $widget_3[0]['s_content']; ?>
    		</div>
        <?php endif; ?>
	</div>
</div><!-- .botwidg -->

<footer class="m_box footer">
	<div class="m_inb f_top">
		<div class="f_copy">
			<div class="f_copy-ins">
                <?php if(osc_get_preference('ft_logo_status', 'marketplace_theme') && file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/bg-logo-white.png")): ?>
				    <a href="<?php echo osc_base_url(); ?>" class="h_logo f_logo"><img src="<?php echo osc_current_web_theme_url("images/bg-logo-white.png?v=" . time()); ?>" /></a>
                <?php endif; ?>
				<div class="f_copy-info"><?php echo osc_get_preference('ft_text', 'marketplace_theme'); ?></div>
			</div>
			<div class="f_copy-cont">
                <?php if(osc_get_preference('ft_address', 'marketplace_theme')): ?>
				    <div class="f_copy-item f_copy-item__address"><?php echo osc_get_preference('ft_address', 'marketplace_theme'); ?></div>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_phone', 'marketplace_theme')): ?>
				    <a href="tel:<?php echo osc_get_preference('ft_phone', 'marketplace_theme'); ?>" class="f_copy-item f_copy-item__tel"><?php echo osc_get_preference('ft_phone', 'marketplace_theme'); ?></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_email', 'marketplace_theme')): ?>
				    <a href="mailto:<?php echo osc_get_preference('ft_email', 'marketplace_theme'); ?>" class="f_copy-item f_copy-item__mail"><?php echo osc_get_preference('ft_email', 'marketplace_theme'); ?></a>
                <?php endif; ?>
			</div>
		</div>
        
        <?php if(osc_get_preference('ft_r_items_status', 'marketplace_theme') && osc_count_latest_items()): ?>
            <?php osc_reset_latest_items(); ?>
    		
            <div class="f_recent">
    			<div class="f_head"><?php _e('Recent and post', 'marketplace') ?></div>
    			<div class="f_recent-list">
                    <?php $i = 1; while(osc_has_latest_items()): ?>
        				<div class="f_recent-item">
                            <div class="f_recent-item__thumb">
                                <?php if(osc_images_enabled_at_items() && osc_count_item_resources()):?>
            					   <img src="<?php echo osc_resource_thumbnail_url(); ?>" alt="recent">
                                <?php else: ?>
                                    <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="recent">
                                <?php endif; ?>
        					</div>
                            
                            <div class="f_recent-item__info">
        						<div class="f_recent-item__cat"><?php _e('Category', 'marketplace') ?>: <a href="<?php echo marketplace_category_url(marketplace_category_root(osc_item_category_id())); ?>"><?php echo marketplace_category_root_name(osc_item_category_id()); ?></a></div>
        						<a href="<?php echo osc_item_url(); ?>" class="f_recent-item__title">
                                    <?php if(strlen(osc_item_title()) > 25) echo mb_substr(osc_item_title(), 0, 23,'UTF-8') . '...'; else echo osc_item_title(); ?>
                                </a>
                                
                                <?php if(osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_item_category_id())): ?>
        						  <div class="f_recent-item__price"><?php _e('Price', 'marketplace') ?>: <span><?php echo osc_item_formated_price(); ?></span></div>
                                <?php endif; ?>
        					</div>
        				</div>
                        
                        <?php $i++; ?>
                        <?php if($i > 3) break; ?>
                    <?php endwhile; ?>
    			</div>
    		</div>
        <?php endif; ?>
        
        <?php if(osc_count_static_pages()): ?>
            <?php osc_reset_static_pages(); ?>
    		<div class="f_about">
    			<div class="f_head"><?php _e('About us', 'marketplace') ?></div>
    			<ul class="f_tags">
                    <?php while(osc_has_static_pages()): ?>
    				    <li><a href="<?php echo osc_static_page_url(); ?>" title="<?php echo osc_esc_html(osc_static_page_title()); ?>"><?php echo ucfirst(osc_static_page_title());?></a></li>
                    <?php endwhile; ?>
    				<li><a href="<?php echo osc_contact_url(); ?>" ><?php _e('Contact', 'marketplace'); ?></a></li>
    			</ul>
    		</div>
        <?php endif; ?>
        
        <?php if(osc_get_preference('ft_categories_status', 'marketplace_theme') && osc_count_categories()): ?>
            <?php osc_goto_first_category(); ?>
    		<div class="f_about">
    			<div class="f_head"><?php _e('Categories', 'marketplace') ?></div>
    			<ul class="f_tags">
                    <?php while(osc_has_categories()): ?>
    				    <li>
                            <a href="<?php echo osc_search_category_url(); ?>">
                                <?php if(strlen(osc_category_name()) > 25) echo mb_substr(osc_category_name(), 0, 23,'UTF-8') . '...'; else echo osc_category_name(); ?>
                            </a>
                        </li>
                    <?php endwhile; ?>
    			</ul>
    		</div>
        <?php endif; ?>
	</div>
	<div class="f_bot">
		<div class="m_inb">
			<div class="f_bot-copy"><?php echo date("Y"); ?><?php echo osc_get_preference('ft_copyright', 'marketplace_theme'); ?></div>
			<div class="f_social">
                <?php if(osc_get_preference('ft_facebook', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_facebook', 'marketplace_theme'); ?>" class="f_social-item f_social-item__fb" target="_blank"></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_vk', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_vk', 'marketplace_theme'); ?>" class="f_social-item f_social-item__vk" target="_blank"></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_google', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_google', 'marketplace_theme'); ?>" class="f_social-item f_social-item__gp" target="_blank"></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_twitter', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_twitter', 'marketplace_theme'); ?>" class="f_social-item f_social-item__tw" target="_blank"></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_ln', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_ln', 'marketplace_theme'); ?>" class="f_social-item f_social-item__in" target="_blank"></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_pinterest', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_pinterest', 'marketplace_theme'); ?>" class="f_social-item f_social-item__pi" target="_blank"></a>
                <?php endif; ?>
                
                <?php if(osc_get_preference('ft_ok', 'marketplace_theme')): ?>
				    <a href="<?php echo osc_get_preference('ft_ok', 'marketplace_theme'); ?>" class="f_social-item f_social-item__ok" target="_blank"></a>
                <?php endif; ?>
			</div>
		</div>
	</div>
</footer><!-- .footer -->

<?php osc_run_hook('footer'); ?>