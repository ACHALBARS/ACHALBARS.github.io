<style>
.h_publish {
    background-color: <?php echo osc_get_preference('color_publish_item', 'marketplace_theme'); ?>; 
}
.h_publish:hover {
    background-color: <?php echo osc_get_preference('color_publish_item_hover', 'marketplace_theme'); ?>;
}
.c_maincat-box__search input[type="submit"], .c_btn, .c_item-more, .c_form-upload__btn, .c_form input[type="submit"], .s_search-submit input, .c_reg-btn input[type="submit"],button {
    background-color: <?php echo osc_get_preference('color_other_btns', 'marketplace_theme'); ?>;
}
.c_maincat-box__search input[type="submit"]:hover, .c_btn:hover, .c_item-more:hover, .c_form-upload__btn:hover, .c_form input[type="submit"]:hover, .s_search-submit input:hover, .c_reg-btn input[type="submit"]:hover,button:hover {
    background-color: <?php echo osc_get_preference('color_other_btns_hover', 'marketplace_theme'); ?>;
}
.c_reg-top,.c_reg-top a {
    background-color: <?php echo osc_get_preference('color_forms_bg_header', 'marketplace_theme'); ?>;
    color: <?php echo osc_get_preference('color_forms_font_header', 'marketplace_theme'); ?>;
}
.s_box-dark {
    background-color: <?php echo osc_get_preference('color_side_block_bg_header', 'marketplace_theme'); ?>;
    color: <?php echo osc_get_preference('color_side_block_font_header', 'marketplace_theme'); ?>;
}
.s_info-cat, .c_item-cat {
    background-color: <?php echo osc_get_preference('color_category_label_bg', 'marketplace_theme'); ?>;
    color: <?php echo osc_get_preference('color_category_label_font', 'marketplace_theme'); ?>;
}
.s_info-cat:hover, .c_item-cat:hover {
  background-color: <?php echo osc_get_preference('color_category_label_bg_hover', 'marketplace_theme'); ?>;
  color: <?php echo osc_get_preference('color_category_label_font_hover', 'marketplace_theme'); ?>;
}
.c_item-favorite {
    background-color: <?php echo osc_get_preference('color_prem_item_label_bg', 'marketplace_theme'); ?>!important;
}
.pagination{
    width: 100%;
    text-align: center;
    margin: 15px 0 30px 15px;
}
.pagination ul {
    text-align: left;
}
.pagination ul li{
    list-style-type: none;
    display:inline-block;
}
.searchPaginationNonSelected,
.searchPaginationNext,
.searchPaginationPrev,
.searchPaginationFirst,
.searchPaginationLast {
	background: #fff;
    border: 1px solid #F2F2F2;
    border-radius: 5px;
    margin: 0 5px 9px 0;
    color: #444343;
    padding: 13px 18px;
    line-height: 1;
}
.searchPaginationNonSelected:hover,
.searchPaginationNext:hover,
.searchPaginationPrev:hover,
.searchPaginationFirst:hover,
.searchPaginationLast:hover {
    background-color: <?php echo osc_get_preference('color_other_btns_hover', 'marketplace_theme'); ?>;
    color: #fff;
    border-color: transparent;
}
.searchPaginationSelected{
    background-color: <?php echo osc_get_preference('color_other_btns', 'marketplace_theme'); ?>;
    border-radius: 5px;
    margin: 0 5px 9px 0;
    color: #fff;
    padding: 13px 18px;
    line-height: 1;
}
/*
.c_item-more:hover {
  background-color: #00a443;
}

.c_btn:hover {
  background-color: #00913b;
}

.c_form-upload__btn:hover {
  background-color: #007c33;
}

.c_form input[type="submit"]:hover {
  background-color: #007c33;
}

.s_search-submit input:hover {
  background-color: #00953c;
}
*/
</style>