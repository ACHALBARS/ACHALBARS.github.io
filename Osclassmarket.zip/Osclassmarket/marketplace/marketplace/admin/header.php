<?php defined('ABS_PATH') or die('Access denied'); 
/*
* Copyright 2020 osclass-pro.com
* 
* You shall not distribute this theme and any its files (except third-party libraries) to third parties.
* Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
*/

    require_once 'functions.php';
    marketplace_admin_scripts();
?>

<div class="ua-manage-wrapper">
    <div style="margin: 15px;">
        <?php if(is_writable(WebThemes::newInstance()->getCurrentThemePath() . "images/")): ?>
            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.png")): ?>
                <h3><?php _e('Preview', 'marketplace') ?></h3>
                
                <table class="table table-no-border">
                    <tr>
                        <td style="width: 180px;"><img border="0" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/logo.png');?>" /></td>
                    </tr>
                    
                    <tr>
                        <td>
                            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/header.php');?>" method="post" enctype="multipart/form-data">
                              <input type="hidden" name="action_specific" value="remove" />
                    
                              <button type="submit" class="custom-btn round-corner-btn btn-danger"><?php echo osc_esc_html(__('Remove Logo','marketplace')); ?></button>
                            </form>
                        </td>
                    </tr>
                </table>
            <?php else: ?>
                <div class="alert alert-warning">
                    <p><?php _e('No logo has been uploaded yet', 'marketplace'); ?></p>
                </div>
            <?php endif; ?>
            
            <h3><?php _e('Upload logo', 'marketplace') ?></h3>
            
            <div class="alert alert-info">
                <p>
                    <?php _e('The recomended size of the logo is ~', 'marketplace'); ?> 170x50.
                </p>
                
                <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.png")): ?>
                    <p><?php _e('<strong>Note:</strong> Uploading another logo will overwrite the current logo.', 'marketplace'); ?></p>
                <?php endif; ?>
                
                <p><?php _e('Following formats are allowed: png, gif, jpg','marketplace'); ?></p>
            </div>
            
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/header.php'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="upload_logo" />
                
                <table class="table table-no-border">
                    <tr>
                        <td style="width: 180px;"><input type="file" name="logo" id="package" /></td>
                    </tr>
                    
                    <tr>
                        <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload Logo','marketplace')); ?></button></td>
                    </tr>
                </table>
            </form>
        <?php else: ?>
        <div class="alert alert-warning">
            <p>
                <?php
                    $msg  = sprintf(__('The images folder <strong>%s</strong> is not writable on your server', 'marketplace'), WebThemes::newInstance()->getCurrentThemePath() ."images/" ) .", ";
                    $msg .= __("OSClass can't upload the logo image from the administration panel.", 'marketplace') . ' ';
                    $msg .= __("Please make the aforementioned image folder writable.", 'marketplace') . ' ';
                    echo $msg;
                ?>
            </p>
            <p>
                <?php _e('To make a directory writable under UNIX execute this command from the shell:','marketplace'); ?>
            </p>
            <p class="command">
                chmod a+w <?php echo WebThemes::newInstance()->getCurrentThemePath() ."images/" ; ?>
            </p>
        </div>
        <?php endif; ?>
    </div>
</div>