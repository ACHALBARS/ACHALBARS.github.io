<?php defined('ABS_PATH') or die('Access denied'); 
    /*
    * Copyright 2018 osclass-pro.com
    *
    * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
    * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
    */
    
    function marketplace_admin_scripts($title = NULL) { 
        echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">';
        echo '<link href="' . osc_current_web_theme_url('admin/css/hurkanSwitch.css?v=' . time()) . '" rel="stylesheet" type="text/css" />';
        echo '<link href="' . osc_current_web_theme_url('admin/css/tipso.css?v=' . time()) . '" rel="stylesheet" type="text/css" />';
        echo '<link href="' . osc_current_web_theme_url('admin/css/animate.css') . '" rel="stylesheet" type="text/css" />';
        echo '<link href="' . osc_current_web_theme_url('admin/css/tabs.css?v=' . time()) . '" rel="stylesheet" type="text/css" />';
        echo '<link href="' . osc_current_web_theme_url('admin/css/accordion.css?v=') . time() . '" rel="stylesheet" type="text/css" />';
        echo '<link href="' . osc_current_web_theme_url('admin/css/style.css?v=' . time()) . '" rel="stylesheet" type="text/css" />';
        echo '<script src="' . osc_current_web_theme_url('admin/js/hurkanSwitch.js?v=' . time()) . '"></script>';
        echo '<script src="' . osc_current_web_theme_url('admin/js/tipso.js?v=' . time()) . '"></script>';
        echo '<script src="' . osc_current_web_theme_url('admin/js/tabs.js?v=' . time()) . '"></script>';
        echo '<script src="' . osc_current_web_theme_url('admin/js/script.js?v=' . time()) . '"></script>';
    }
    
    function marketplace_top_menu($menu = '') {
        $current = Params::getParam('m');
        
        if($current == $menu) return true;
        
        return false;
    }
    
    function marketplace_left_menu($menu = '') {
        $current = Params::getParam('l');
        
        if($current == $menu) return true;
        
        return false;
    }
?>