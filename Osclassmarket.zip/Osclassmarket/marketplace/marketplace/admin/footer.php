<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=footer'); ?>" method="post">
                <input type="hidden" name="action_specific" value="marketplace_footer_settings" />
                
                <table class="table-striped table-2-cols">
                    <tr>
                        <td><?php _e('Logo', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="ft_logo_status" value="1" <?php echo (osc_get_preference('ft_logo_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Recent Items', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="ft_r_items_status" value="1" <?php echo (osc_get_preference('ft_r_items_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Categories', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="ft_categories_status" value="1" <?php echo (osc_get_preference('ft_categories_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Footer Text', 'marketplace') ?>:</td>
                        <td><textarea name="ft_text" rows="8"><?php echo osc_esc_html(osc_get_preference('ft_text', 'marketplace_theme')); ?></textarea></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Address', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_address" value="<?php echo osc_esc_html(osc_get_preference('ft_address', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Contact Phone', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_phone" value="<?php echo osc_esc_html(osc_get_preference('ft_phone', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('E-mail', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_email" value="<?php echo osc_esc_html(osc_get_preference('ft_email', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Copyright', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_copyright" value="<?php echo osc_esc_html(osc_get_preference('ft_copyright', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Facebook Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_facebook" value="<?php echo osc_esc_html(osc_get_preference('ft_facebook', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Twitter Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_twitter" value="<?php echo osc_esc_html(osc_get_preference('ft_twitter', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Instagram Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_google" value="<?php echo osc_esc_html(osc_get_preference('ft_google', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('LinkedIn Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_ln" value="<?php echo osc_esc_html(osc_get_preference('ft_ln', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Pinterest Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_pinterest" value="<?php echo osc_esc_html(osc_get_preference('ft_pinterest', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Vkontakte Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_vk" value="<?php echo osc_esc_html(osc_get_preference('ft_vk', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Odnoklassniki Profile Link', 'marketplace') ?>:</td>
                        <td><input type="text" name="ft_ok" value="<?php echo osc_esc_html(osc_get_preference('ft_ok', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                </table> 
                
                <div class="form-actions">
                    <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                </div>        
            </form>
            
            <h3><?php _e('Upload Footer Logo', 'marketplace') ?></h3>
            <div class="alert alert-info">
                <p>
                    <?php _e('The recomended size of the logo is ~', 'marketplace'); ?> 265x40.
                </p>
                
                <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/bg-logo-white.png")): ?>
                    <p><?php _e('<strong>Note:</strong> Uploading another logo will overwrite the current logo.', 'marketplace'); ?></p>
                <?php endif; ?>
                
                <p><?php _e('Following formats are allowed: png, gif, jpg','marketplace'); ?></p>
            </div>
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=footer'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_upload_footer_logo" />
                
                <table class="table table-no-border">
                    <tr>
                        <td><img border="0" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/bg-logo-white.png');?>" /></td>
                    </tr>
        
                    <tr>
                        <td style="width: 180px;"><input id="footer-logo" type="file" name="footer_logo" accept="image/*" /></td>
                    </tr>
                    
                    <tr>
                        <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload Logo','marketplace')); ?></button></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>