<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=items'); ?>" method="post">
                <input type="hidden" name="action_specific" value="marketplace_items_settings" />
                
                <table class="table-striped table-2-cols">
                    <tr><td colspan="2" style="background: #474749;padding: 15px;color: #fff;text-shadow: none;"><?php _e('Item-post options', 'marketplace') ?></td></tr>
                    
                    <tr>
                        <td><?php _e('Location option', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_location" value="1" <?php echo (osc_get_preference('item_location', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Countries', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_countries" value="1" <?php echo (osc_get_preference('item_countries', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Custom fileds postion', 'marketplace') ?>:</td>
                        <td>
                            <select name="item_fields_position">
                                <option value="after" <?php if(osc_get_preference('item_fields_position', 'marketplace_theme') == "after") echo 'selected';?>>
                                    <?php _e('After Categories', 'marketplace') ?>
                                </option>
                                
                                <option value="bottom" <?php if(osc_get_preference('item_fields_position', 'marketplace_theme') == "bottom") echo 'selected';?>>
                                    <?php _e('Bottom', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr><td colspan="2" style="background: #474749;padding: 15px;color: #fff;text-shadow: none;"><?php _e('Item page', 'marketplace') ?></td></tr>
                    
                    <tr>
                        <td><?php _e('Hide phones to XXXX', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_hide_phone" value="1" <?php echo (osc_get_preference('item_hide_phone', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Mark as in item page', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_mark" value="1" <?php echo (osc_get_preference('item_mark', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Google Map', 'marketplace') ?>
						<i id="tips" data-tipso='<?php _e('If you want use plugin for Yandex Map, Openstreet or other maps. Enable this option, but leave empty Google Maps JavaScript API key in Basic Settings.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        :</td>
						<td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_google_map" value="1" <?php echo (osc_get_preference('item_google_map', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Show useful info in item page', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_useful_info_status" value="1" <?php echo (osc_get_preference('item_useful_info_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Useful info text', 'marketplace') ?>:</td>
                        <td><textarea name="item_useful_info_text" rows="8"><?php echo osc_esc_html(osc_get_preference('item_useful_info_text', 'marketplace_theme')); ?></textarea></td>
                    </tr>
                </table> 
                
                <div class="form-actions">
                    <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                </div>        
            </form>
        </div>
    </div>
</div>