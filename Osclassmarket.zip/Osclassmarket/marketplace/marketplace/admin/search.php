<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=search'); ?>" method="post">
                <input type="hidden" name="action_specific" value="marketplace_search_settings" />
                
                <table class="table-striped table-2-cols">
                    <tr>
                        <td><?php _e('Advanced search Country field', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="search_country_field_status" value="1" <?php echo (osc_get_preference('search_country_field_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Search Block Position', 'marketplace') ?>:</td>
                        <td>
                            <select name="search_position">
                                <option value="left" <?php if(osc_get_preference('search_position', 'marketplace_theme') == "left") echo 'selected';?>>
                                    <?php _e('Left', 'marketplace') ?>
                                </option>
                                
                                <option value="right" <?php if(osc_get_preference('search_position', 'marketplace_theme') == "right") echo 'selected';?>>
                                    <?php _e('Right', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('No. of Premium items', 'marketplace') ?>:</td>
                        <td>
                            <input class="text" type="text" name="search_premium_num_ads" value="<?php echo osc_esc_html(osc_get_preference('search_premium_num_ads', 'marketplace_theme')); ?>" />
                        </td>
                    </tr>
                </table> 
                
                <div class="form-actions">
                    <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                </div>        
            </form>
        </div>
    </div>
</div>