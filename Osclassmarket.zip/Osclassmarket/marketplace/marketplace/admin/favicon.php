<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <h3><?php _e('Upload Favicon', 'marketplace') ?></h3>
            <div class="alert alert-info">
                <p>
                    <?php _e('The recomended size of the favicon is ~', 'marketplace'); ?> 16x16.
                </p>
                
                <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/favicon.png")): ?>
                    <p><?php _e('<strong>Note:</strong> Uploading another favicon will overwrite the current favicon.', 'marketplace'); ?></p>
                <?php endif; ?>
                
                <p><?php _e('Following formats are allowed: png','marketplace'); ?></p>
            </div>
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=favicon'); ?>" method="post" enctype="multipart/form-data" class="nocsrf">
                <input type="hidden" name="action_specific" value="marketplace_upload_favicon" />
                
                <table class="table table-no-border">
                    <tr>
                        <td>
                            <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/favicon.png")): // ПОПРАВИТЬ ПУТЬ К ИКОНКЕ!!!!!! ?>
                                <img border="0" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/favicon.png');?>" />
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <p><?php _e('No image has been uploaded yet', 'marketplace'); ?></p>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
        
                    <tr>
                        <td style="width: 180px;"><input id="marketplace-favicon" type="file" name="marketplace_favicon" accept="image/*" /></td>
                    </tr>
                    
                    <tr>
                        <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload Favicon','marketplace')); ?></button></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>