<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=items'); ?>" method="post">
                <input type="hidden" name="action_specific" value="marketplace_related_items_settings" />
                
                <table class="table-striped table-2-cols">
                    <tr>
                        <td>
                            <?php _e('Number of related ads', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Enter how many ads you want to show on Item Page (Default is 4)', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td><input type="text" name="related_items_num" value="<?php echo osc_esc_html(osc_get_preference('related_items_num', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Show only premium ads', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Select Yes if you want to show premium ads only', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="related_items_premium_only" value="1" <?php echo (osc_get_preference('related_items_premium_only', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Show ads with pictures only', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Select Yes if you want to show ads with picture only', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="related_items_pic_only" value="1" <?php echo (osc_get_preference('related_items_pic_only', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Show ads with same category', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Select Yes to Filter ads by Category', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="related_items_same_cats" value="1" <?php echo (osc_get_preference('related_items_same_cats', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Show ads with same country', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Select Yes to Filter ads by Country', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="related_items_country" value="1" <?php echo (osc_get_preference('related_items_country', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Show ads with same region', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Select Yes to Filter ads by Region', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="related_items_region" value="1" <?php echo (osc_get_preference('related_items_region', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                </table> 
                
                <div class="form-actions">
                    <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                </div>        
            </form>
        </div>
    </div>
</div>