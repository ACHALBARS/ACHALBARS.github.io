<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <div style="margin:15px;">
        <div class="alert alert-info">
            <p><?php _e('The recomended size of the partner\'s logo is ~', 'marketplace'); ?> 123х55.</p>
            <p><?php _e('<strong>Note:</strong> Uploading another logo will overwrite the current logo.', 'marketplace'); ?></p>
            <p><?php _e('Following format is allowed: jpg','marketplace'); ?></p>
        </div>
        
        <table class="table-striped">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_brands_logo" />
                <input type="hidden" name="brand_id" value="1" />
                
                <tr>
                    <td><strong><?php _e('Image #1', 'marketplace'); ?></strong></td>
                    <td>
                        <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner1.jpg")): ?>
                            <img border="0" style="max-width: 123px;" src="<?php echo osc_current_web_theme_url('images/partner1.jpg');?>" />
                        <?php else: ?>
                            <?php _e('No Image', 'marketplace'); ?>
                        <?php endif; ?>
                    </td>
                    <td><input type="file" name="brand_image" id="package" accept="image/jpeg"/></td>
                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                </tr>
            </form>
            
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_brands_logo" />
                <input type="hidden" name="brand_id" value="2" />
                
                <tr>
                    <td><strong><?php _e('Image #2', 'marketplace'); ?></strong></td>
                    <td>
                        <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner2.jpg")): ?>
                            <img border="0" style="max-width: 123px;" src="<?php echo osc_current_web_theme_url('images/partner2.jpg');?>" />
                        <?php else: ?>
                            <?php _e('No Image', 'marketplace'); ?>
                        <?php endif; ?>
                    </td>
                    <td><input type="file" name="brand_image" id="package" accept="image/jpeg"/></td>
                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                </tr>
            </form>
            
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_brands_logo" />
                <input type="hidden" name="brand_id" value="3" />
                
                <tr>
                    <td><strong><?php _e('Image #3', 'marketplace'); ?></strong></td>
                    <td>
                        <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner3.jpg")): ?>
                            <img border="0" style="max-width: 123px;" src="<?php echo osc_current_web_theme_url('images/partner3.jpg');?>" />
                        <?php else: ?>
                            <?php _e('No Image', 'marketplace'); ?>
                        <?php endif; ?>
                    </td>
                    <td><input type="file" name="brand_image" id="package" accept="image/jpeg"/></td>
                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                </tr>
            </form>
            
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_brands_logo" />
                <input type="hidden" name="brand_id" value="4" />
                
                <tr>
                    <td><strong><?php _e('Image #4', 'marketplace'); ?></strong></td>
                    <td>
                        <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner4.jpg")): ?>
                            <img border="0" style="max-width: 123px;" src="<?php echo osc_current_web_theme_url('images/partner4.jpg');?>" />
                        <?php else: ?>
                            <?php _e('No Image', 'marketplace'); ?>
                        <?php endif; ?>
                    </td>
                    <td><input type="file" name="brand_image" id="package" accept="image/jpeg"/></td>
                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                </tr>
            </form>
            
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_brands_logo" />
                <input type="hidden" name="brand_id" value="5" />
                
                <tr>
                    <td><strong><?php _e('Image #5', 'marketplace'); ?></strong></td>
                    <td>
                        <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner5.jpg")): ?>
                            <img border="0" style="max-width: 123px;" src="<?php echo osc_current_web_theme_url('images/partner5.jpg');?>" />
                        <?php else: ?>
                            <?php _e('No Image', 'marketplace'); ?>
                        <?php endif; ?>
                    </td>
                    <td><input type="file" name="brand_image" id="package" accept="image/jpeg"/></td>
                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                </tr>
            </form>
            
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/brands.php&m=brands'); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action_specific" value="marketplace_brands_logo" />
                <input type="hidden" name="brand_id" value="6" />
                
                <tr>
                    <td><strong><?php _e('Image #6', 'marketplace'); ?></strong></td>
                    <td>
                        <?php if(file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/partner6.jpg")): ?>
                            <img border="0" style="max-width: 123px;" src="<?php echo osc_current_web_theme_url('images/partner6.jpg');?>" />
                        <?php else: ?>
                            <?php _e('No Image', 'marketplace'); ?>
                        <?php endif; ?>
                    </td>
                    <td><input type="file" name="brand_image" id="package" accept="image/jpeg"/></td>
                    <td><button type="submit" class="custom-btn round-corner-btn btn-success"><?php echo osc_esc_html(__('Upload','marketplace')); ?></button></td>
                </tr>
            </form>
        </table> 
    </div>
</div>