<?php defined('ABS_PATH') or die('Access denied'); ?>

<?php require_once 'top-menu.php'; ?>
<div class="ua-manage-wrapper">
    <?php require_once 'left-menu.php'; ?>
    <div class="ua-manage-content ua-section">
        <div style="margin:15px;">
            <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/settings.php&m=settings&l=basic'); ?>" method="post">
                <input type="hidden" name="action_specific" value="marketplace_basic_settings" />
                
                <table class="table-striped table-2-cols">
                    <tr>
                        <td><?php _e('Search placeholder', 'marketplace') ?>:</td>
                        <td><input type="text" name="keyword_placeholder" value="<?php echo osc_esc_html(osc_get_preference('keyword_placeholder', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Show lists in Search pages as', 'marketplace') ?>:</td>
                        <td>
                            <select name="default_show_items">
                                <option value="gallery" <?php if(osc_get_preference('default_show_items', 'marketplace_theme') == "gallery") echo 'selected';?>>
                                    <?php _e('Gallery', 'marketplace') ?>
                                </option>
                                
                                <option value="list" <?php if(osc_get_preference('default_show_items', 'marketplace_theme') == "list") echo 'selected';?>>
                                    <?php _e('List', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Category Icon in latest and search items', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="item_icon" value="1" <?php echo (osc_get_preference('item_icon', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Search in Main page with Subcategories', 'marketplace') ?>:
                        </td>
                        
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="subcategories" value="1" <?php echo (osc_get_preference('subcategories', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Search in Main page select options', 'marketplace') ?>:
						                            <i id="tips" data-tipso='<p><?php _e('Search select option(Use the With all cities option in the search, if you have a single region or not many regions.', 'marketplace'); ?></p><p><?php _e('If you have many regions or countries. Home page can be opened for a long time with this option.)', 'marketplace'); ?></p>' class="fa fa-question-circle fa-help"></i>
						</td>
                        <td>
                            <select name="main_search">
                                <option value="all" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "all") echo 'selected';?>><?php _e('With all Options', 'marketplace') ?></option>
                                <option value="inc.search.autocomplete" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.autocomplete") echo 'selected';?>>
                                    <?php _e('City autocomplete', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.searchcitybyreg" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.searchcitybyreg") echo 'selected';?>>
                                    <?php _e('Cities by regions', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.regions" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.regions") echo 'selected';?>>
                                    <?php _e('With all Regions', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.items" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.items") echo 'selected';?>>
                                    <?php _e('Regions with items', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.city" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.city") echo 'selected';?>>
                                    <?php _e('With all Cities', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.city.items" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.city.items") echo 'selected';?>>
                                    <?php _e('Cities with items', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.countries" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.countries") echo 'selected';?>>
                                    <?php _e('Countries with items', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.hide" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.hide") echo 'selected';?>>
                                    <?php _e('Hide location', 'marketplace') ?>
                                </option>
                                
                                <option value="inc.search.null" <?php if(osc_get_preference('main_search', 'marketplace_theme') == "inc.search.null") echo 'selected';?>>
                                    <?php _e('Hide search', 'marketplace') ?>
                                </option>
                                
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Categories in main page', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="categoriesmain" value="1" <?php echo (osc_get_preference('categoriesmain', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Categories description', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('You can add for each Osclass category some text with HTML tags in Settings - Categories. This text can be displayed on the category page.', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        <td>
                            <select name="categories_description">
                                <option value="top" <?php if(osc_get_preference('categories_description', 'marketplace_theme') == "top") echo 'selected';?>>
                                    <?php _e('At the top of the page', 'marketplace') ?>
                                </option>
                                
                                <option value="bottom" <?php if(osc_get_preference('categories_description', 'marketplace_theme') == "bottom") echo 'selected';?>>
                                    <?php _e('At the bottom of the page', 'marketplace') ?>
                                </option>
                                
                                <option value="hide" <?php if(osc_get_preference('categories_description', 'marketplace_theme') == "hide") echo 'selected';?>>
                                    <?php _e('Hide', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Carousel1 in Main page', 'marketplace') ?>:</td>
                        <td>
                            <select name="main_carousel">
                                <option value="premium" <?php if(osc_get_preference('main_carousel', 'marketplace_theme') == "premium") echo 'selected';?>>
                                    <?php _e('Premium items', 'marketplace') ?>
                                </option>
                                
                                <option value="popular" <?php if(osc_get_preference('main_carousel', 'marketplace_theme') == "popular") echo 'selected';?>>
                                    <?php _e('Popular items', 'marketplace') ?>
                                </option>
                                
                                <option value="hide" <?php if(osc_get_preference('main_carousel', 'marketplace_theme') == "hide") echo 'selected';?>>
                                    <?php _e('Hide', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Carousel2 in Main page', 'marketplace') ?>:</td>
                        <td>
                            <select name="main_carousel2">
                                <option value="premium" <?php if(osc_get_preference('main_carousel2', 'marketplace_theme') == "premium") echo 'selected';?>>
                                    <?php _e('Premium items', 'marketplace') ?>
                                </option>
                                
                                <option value="popular" <?php if(osc_get_preference('main_carousel2', 'marketplace_theme') == "popular") echo 'selected';?>>
                                    <?php _e('Popular items', 'marketplace') ?>
                                </option>
                                
                                <option value="hide" <?php if(osc_get_preference('main_carousel2', 'marketplace_theme') == "hide") echo 'selected';?>>
                                    <?php _e('Hide', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('No. of items in carousel', 'marketplace') ?>:</td>
                        <td><input type="text" name="carousel_num_ads" value="<?php echo osc_esc_html(osc_get_preference('carousel_num_ads', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('No. of items in Latest Items Block', 'marketplace') ?>:</td>
                        <td><input type="text" name="lib_num_ads" value="<?php echo osc_esc_html(osc_get_preference('lib_num_ads', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Main Partner Logos Block', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="main_brands_block_status" value="1" <?php echo (osc_get_preference('main_brands_block_status', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Main Google Map', 'marketplace') ?>:</td>
                        <td>
                            <div data-toggle="switch">
                                <input class="checkbox" type="checkbox" name="main_map" value="1" <?php echo (osc_get_preference('main_map', 'marketplace_theme') ? 'checked="true"' : ''); ?> />
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Google Map style', 'marketplace') ?>:</td>
                        <td>
                            <select name="map_style">
                                <option value="default" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "default") echo 'selected';?>>
                                    <?php _e('default', 'marketplace') ?>
                                </option>
                                
                                <option value="light-monochrome" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "light-monochrome") echo 'selected';?>>
                                    <?php _e('light-monochrome', 'marketplace') ?>
                                </option>
                                
                                <option value="flat-map" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "flat-map") echo 'selected';?>>
                                    <?php _e('flat-map', 'marketplace') ?>
                                </option>
                                
                                <option value="gowalla" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "gowalla") echo 'selected';?>>
                                    <?php _e('gowalla', 'marketplace') ?>
                                </option>
                                
                                <option value="shift-worker" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "shift-worker") echo 'selected';?>>
                                    <?php _e('shift-worker', 'marketplace') ?>
                                </option>
                                
                                <option value="bentley" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "bentley") echo 'selected';?>>
                                    <?php _e('bentley', 'marketplace') ?>
                                </option>
                                
                                <option value="subtle-grayscale" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "subtle-grayscale") echo 'selected';?>>
                                    <?php _e('subtle-grayscale', 'marketplace') ?>
                                </option>
                                
                                <option value="cool-grey" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "cool-grey") echo 'selected';?>>
                                    <?php _e('cool-grey', 'marketplace') ?>
                                </option>
                                
                                <option value="black-and-white" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "black-and-white") echo 'selected';?>>
                                    <?php _e('black-and-white', 'marketplace') ?>
                                </option>
                                
                                <option value="muted-monotone" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "muted-monotone") echo 'selected';?>>
                                    <?php _e('muted-monotone', 'marketplace') ?>
                                </option>
                                
                                <option value="just-places" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "just-places") echo 'selected';?>>
                                    <?php _e('just-places', 'marketplace') ?>
                                </option>
                                
                                <option value="homage-to-toner" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "homage-to-toner") echo 'selected';?>>
                                    <?php _e('homage-to-toner', 'marketplace') ?>
                                </option>
                                
                                <option value="ultra-light-with-labels" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "ultra-light-with-labels") echo 'selected';?>>
                                    <?php _e('ultra-light-with-labels', 'marketplace') ?>
                                </option>
                                
                                <option value="mikiwat" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "mikiwat") echo 'selected';?>>
                                    <?php _e('mikiwat', 'marketplace') ?>
                                </option>
                                
                                <option value="light-dream" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "light-dream") echo 'selected';?>>
                                    <?php _e('light-dream', 'marketplace') ?>
                                </option>
                                
                                <option value="properta" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "properta") echo 'selected';?>>
                                    <?php _e('properta', 'marketplace') ?>
                                </option>
                                
                                <option value="respedge" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "respedge") echo 'selected';?>>
                                    <?php _e('respedge', 'marketplace') ?>
                                </option>
                                
                                <option value="marketplace" <?php if(osc_get_preference('map_style', 'marketplace_theme') == "marketplace") echo 'selected';?>>
                                    <?php _e('marketplace', 'marketplace') ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Google Maps JavaScript Api Key', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('You can get Key here:', 'marketplace'); ?> <a target="_blank" href="https://developers.google.com/maps/documentation/javascript/get-api-key?hl=en"><?php _e('Get API Key', 'marketplace'); ?></a>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        
                        <td><input type="text" name="map_api_key" value="<?php echo osc_esc_html(osc_get_preference('map_api_key', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('Google Geocoding Api Key', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Read', 'marketplace'); ?> <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/help.php&m=help'); ?>"><?php _e('Help', 'marketplace'); ?></a> <?php _e('about keys', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        
                        <td><input type="text" name="map_geo_key" value="<?php echo osc_esc_html(osc_get_preference('map_geo_key', 'marketplace_theme')); ?>" /></td>
                    </tr>
                    
                    <tr>
                        <td>
                            <?php _e('No. of items in Map', 'marketplace') ?>:
                            <i id="tips" data-tipso='<?php _e('Read', 'marketplace'); ?> <a href="<?php echo osc_admin_render_theme_url('oc-content/themes/' . osc_current_web_theme() . '/admin/help.php&m=help'); ?>"><?php _e('Help', 'marketplace'); ?></a> <?php _e('before setting up', 'marketplace'); ?>' class="fa fa-question-circle fa-help"></i>
                        </td>
                        
                        <td><input type="text" name="map_num_ads" value="<?php echo osc_esc_html(osc_get_preference('map_num_ads', 'marketplace_theme')); ?>" /></td>
                    </tr>
                </table> 
                
                <div class="form-actions">
                    <input type="submit" id="save_changes" value="<?php echo osc_esc_html(__("Save changes", 'marketplace')); ?>" class="btn btn-submit">
                </div>        
            </form>
        </div>
    </div>
</div>