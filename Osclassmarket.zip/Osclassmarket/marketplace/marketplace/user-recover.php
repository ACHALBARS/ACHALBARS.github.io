<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        <div class="c_reg">
        	<div class="c_reg-top">
        		<div class="c_reg-head"><?php _e('Recover your password', 'marketplace') ?></div>
        		<?php _e("Oops! Give us your email and we'll send you an email to get your password back.", 'marketplace') ?>
        	</div>
        	<div class="c_form c_reg-form">
        		<form action="<?php echo osc_base_url(true); ?>" method="post">
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="recover_post" />
                            
        			<div class="c_form-label c_single-form__email">
        				<input id="s_email" type="email" name="s_email">
        				<span class="c_form-placeholder"><?php _e('E-mail', 'marketplace') ?></span>
        			</div>
					<?php osc_show_recaptcha('recover_password'); ?>
        			<div class="c_reg-btn c_forgot-btn">
        				<input type="submit" value="<?php _e('Send me a new password', 'marketplace') ?>">
        			</div>
        		</form>
        	</div>
        </div>
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>