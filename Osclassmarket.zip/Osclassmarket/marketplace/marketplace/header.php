<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<header class="m_box header <?php if(osc_is_home_page()): ?>header__main<?php endif; ?>" style="background-image: url('<?php echo osc_current_web_theme_url('images/bg-head.jpg') ?>');">
	<div class="h_top">
		<a href="<?php echo osc_base_url(); ?>" class="h_logo"><?php echo logo_header(); ?></a>
		
        <div class="h_info">
			<nav class="h_nav">
				<div class="h_nav-btn"><?php _e('Menu', 'marketplace') ?> <span></span></div>
				<ul>
					<li><a href="<?php echo osc_base_url(); ?>"><?php _e('Home', 'marketplace') ?></a></li>
                    <?php if(osc_count_categories()): ?>
                        <?php osc_goto_first_category(); ?>
    					<li class="drop"><a href="#"><?php _e('Categories', 'marketplace') ?></a>
    						<ul class="sub-menu">
                                <?php while(osc_has_categories()): ?>
        							<li <?php if(osc_count_subcategories2()): ?>class="drop"<?php endif; ?>>
                                        <a href="<?php echo osc_search_category_url(); ?>">
                                            <?php if(strlen(osc_category_name()) > 25) echo mb_substr(osc_category_name(), 0, 23,'UTF-8') . '...'; else echo osc_category_name(); ?>
                                        </a>
                                        
                                        <?php if(osc_count_subcategories()): ?>
            								<ul class="sub-menu">
                                                <?php while(osc_has_subcategories()): ?>
            									   <li><a href="<?php echo osc_search_category_url(); ?>"><?php if(strlen(osc_category_name()) > 20) echo mb_substr(osc_category_name(), 0, 20,'UTF-8') . '...'; else echo osc_category_name(); ?></a></li>
                                                <?php endwhile; ?>
            								</ul>
                                        <?php endif; ?>
        							</li>
                                <?php endwhile; ?>
    						</ul>
    					</li>
                    <?php endif; ?>
					<li><a href="<?php echo osc_contact_url(); ?>"><?php _e('Contact', 'marketplace') ?></a></li>
                    <?php if(osc_users_enabled()):?>
                        <?php if(osc_is_web_user_logged_in()): ?>
                            <li><a href="<?php echo osc_user_dashboard_url(); ?>"><?php _e('My account', 'marketplace') ?></a></li>
        					<li><a href="<?php echo osc_user_logout_url(); ?>"><?php _e('Logout', 'marketplace') ?></a></li>
                        <?php else: ?>
        					<li><a href="<?php echo osc_user_login_url(); ?>"><?php _e('Sign in', 'marketplace') ?></a></li>
                            <?php if(osc_user_registration_enabled()): ?>
        					   <li><a href="<?php echo osc_register_account_url(); ?>"><?php _e('Sign up', 'marketplace') ?></a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
				</ul>
			</nav>
            
			<div class="h_search">
				<div class="h_search-body">
					<form action="<?php echo osc_base_url(true); ?>" method="post">
                        <input type="hidden" name="page" value="search" />
						<input type="text" name="sPattern" placeholder="<?php _e('Search', 'marketplace') ?>">
						<input type="submit" value="">
					</form>
				</div>
				<div class="h_search-btn"></div>
			</div>
            <?php if(osc_count_web_enabled_locales() > 1):?>
                <?php osc_goto_first_locale(); ?>
    			
                <div class="h_lang">
    				<div class="h_lang-head"><span><?php _e('Language', 'marketplace') ?>:</span> <div class="h_lang-now"><?php echo strtoupper(substr(osc_current_user_locale(), 0, 2)); ?></div></div>
    				<div class="h_lang-list">
                        <?php while(osc_has_web_enabled_locales()): ?>
    					   <div class="h_lang-item <?php if(osc_locale_code() == osc_current_user_locale()): ?>active<?php endif; ?>" onclick="location.href = '<?php echo osc_change_language_url(osc_locale_code()); ?>'"><?php echo strtoupper(substr(osc_locale_code(), 0, 2)); ?></div>
                        <?php endwhile; ?>
    				</div>
    			</div>
            <?php endif; ?>
		</div>
			<div class="h_pub">
			<a href="<?php echo osc_item_post_url(); ?>" class="h_publish"><?php _e('Publish your ad', 'marketplace') ?></a>
			</div>
	</div>
    
    <?php if(osc_is_home_page()): ?>
	<div class="forcemessages-inline">
    <?php osc_show_flash_message(); ?>
</div>
    	<div class="m_inb h_mid">
    		<h1><?php echo osc_esc_html(osc_get_preference('h1_intro_text', 'marketplace_theme')); ?></h1>
    		<div class="h_mid-desc"><?php echo osc_esc_html(osc_get_preference('h2_intro_text', 'marketplace_theme')); ?></div>
    	</div>
    <?php endif; ?>
</header><!-- .header-->

<?php if(!osc_is_home_page()): ?>
<?php 
    $breadcrumb = osc_breadcrumb('', false);
    $breadcrumb = str_replace('<span itemprop="title">' . osc_page_title() . '</span>', '<span itemprop="title">' . __('Main', 'marketplace') . '</span>', $breadcrumb);
?>
<div class="m_box c_breadcrumbs">
	<div class="m_inb">
        <?php echo $breadcrumb; ?>
	</div>
</div><!-- .breadcrumbs -->
<div class="forcemessages-inline">
    <?php osc_show_flash_message(); ?>
</div>
<?php endif; ?>