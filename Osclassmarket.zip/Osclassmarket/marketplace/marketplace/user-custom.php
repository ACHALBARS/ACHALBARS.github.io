<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        <?php UserForm::location_javascript(); ?>
        
        <main class="m_box c_main c_kabinet c_kabinet-edit">
        	<div class="m_inb">
        		<div class="c_cont">
                    <?php osc_render_file(); ?>
                </div>
        
        		<aside class="c_side">
        
        			<div class="s_box s_kabnav">
        				<ul>
        					<?php echo osc_private_user_menu(get_user_menu()); ?>
        				</ul>
        			</div>
        		</aside>
        	</div>
        </main><!-- .main -->

        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>