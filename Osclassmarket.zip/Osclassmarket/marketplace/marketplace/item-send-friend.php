<?php if(osc_reg_user_post_comments() && osc_is_web_user_logged_in() || !osc_reg_user_post_comments()):?>
	<div class="c_single-box c_single-comment">
		<div class="c_single-head"><?php _e('Comments', 'marketplace') ?></div>
		<div class="c_form c_single-form">
            <ul id="comment_error_list"></ul>
            <?php CommentForm::js_validation(); ?>
            
			<form id="comment_form" action="<?php echo osc_base_url(true); ?>" method="post" name="comment_form">
                <input type="hidden" name="action" value="add_comment" />
                <input type="hidden" name="page" value="item" />
                <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
                
                <?php if(osc_is_web_user_logged_in()): ?>
                    <input type="hidden" name="authorName" value="<?php echo osc_logged_user_name(); ?>" />
                    <input type="hidden" name="authorEmail" value="<?php echo osc_logged_user_email(); ?>" />
                <?php else: ?>
                    <div class="c_form-label c_single-form__user">
						<input id="authorName" type="text" name="authorName">
						<span class="c_form-placeholder"><?php _e('Your name', 'marketplace') ?></span>
					</div>
					<div class="c_form-label c_single-form__email">
						<input id="authorEmail" type="email" name="authorEmail" required>
						<span class="c_form-placeholder"><?php _e('Your e-mail', 'marketplace') ?></span>
					</div>
                <?php endif; ?>
				
				<div class="c_form-label c_single-form__mess">
					<textarea id="body" name="body" required></textarea>
					<span class="c_form-placeholder"><?php _e('Comment', 'marketplace') ?></span>
				</div>
                
				<input type="submit" value="<?php _e('Send', 'marketplace') ?>">
			</form>
		</div>
	</div>
<?php endif; ?>

<?php if(osc_count_item_comments()): ?>
	<div class="c_single-box c_single-commlist">
        <?php while(osc_has_item_comments()): ?>
			<div class="c_single-commitem">
				<div class="c_single-commitem__top">
					<div class="c_single-commitem__thumb">
					</div>
					<div class="c_single-commitem__info">
						<div class="c_single-commitem__name"><?php echo osc_comment_author_name(); ?></div>
						<div class="c_single-commitem__date"><?php echo osc_format_date(osc_comment_pub_date()); ?></div>
					</div>
				</div>
				<div class="c_single-commitem__text"><?php echo nl2br( osc_comment_body() ); ?></div>
                
                <?php if(osc_comment_user_id() && (osc_comment_user_id() == osc_logged_user_id())): ?>
                    <div class="c_single-commitem__delete">
                        <a rel="nofollow" href="<?php echo osc_delete_comment_url(); ?>" title="<?php echo osc_esc_html(__('Delete your comment', 'marketplace')); ?>"><?php _e('Delete', 'marketplace'); ?></a>
                    </div>
                <?php endif; ?>
			</div>
        <?php endwhile; ?>
        
        <div class="pagination" style="text-align: right;">
            <?php echo osc_comments_pagination(); ?>
        </div>
	</div>
<?php endif; ?>