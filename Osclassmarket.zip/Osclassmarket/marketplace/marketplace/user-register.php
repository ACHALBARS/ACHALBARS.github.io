<?php
/*
 * Copyright 2020 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()) ; ?>">
    <head>
        <?php osc_current_web_theme_path('head.php'); ?>
    </head>
    
    <body> 
        <?php osc_current_web_theme_path('header.php'); ?>
        <?php UserForm::js_validation(); ?>
        <?php marketplace_validation_wrapper(); ?>
        
        <div class="c_reg">
        	<div class="c_reg-top">
        		<div class="c_reg-head"><?php _e('Create a new account', 'marketplace') ?></div>
        		<?php _e('This is something really cool to sign up on this website!', 'marketplace') ?>
        	</div>
            
        	<div class="c_form c_reg-form">
        		<form name="register" id="register" class="form-publish" action="<?php echo osc_base_url(true); ?>" method="post">
                    <input type="hidden" name="page" value="register" />
                    <input type="hidden" name="action" value="register_post" />
                                        
        			<div class="c_form-label c_single-form__user">
        				<input id="s_name" type="text" name="s_name">
        				<label for="s_name" class="c_form-placeholder"><?php _e('Name', 'marketplace') ?>*</label>
        			</div>
					<?php if( function_exists( "MyHoneyPot" )) { ?>		
			<?php MyHoneyPot(); ?>		
		<?php } ?>    
        			<div class="c_form-label c_single-form__email">
        				<input id="s_email" type="email" name="s_email">
        				<label for="s_email"  class="c_form-placeholder"><?php _e('E-mail', 'marketplace') ?>*</label>
        			</div>
        			<div class="c_form-label c_single-form__pass">
        				<input id="s_password" type="password" name="s_password">
        				<label for="s_password" class="c_form-placeholder"><?php _e('Password', 'marketplace') ?>*</label >
        			</div>
        			<div class="c_form-label c_single-form__pass">
        				<input id="s_password2" type="password" name="s_password2">
        				<label for="s_password2" class="c_form-placeholder"><?php _e('Repeat password', 'marketplace') ?>*</label>
        			</div>
        			<div class="c_form-label c_single-form__phone">
        				<input id="s_phone_mobile" type="tel" name="s_phone_mobile">
        				<label for="s_phone_mobile" class="c_form-placeholder"><?php _e('Mobile phone', 'marketplace') ?></label>
        			</div>
        			<div class="c_form-label c_select s_search-select c_single-form__user">
        				<select id="b_company" class="selectpicker" data-size="7" name="b_company">
                            <option><?php _e('User', 'marketplace') ?></option>
                            <option><?php _e('Company', 'marketplace') ?></option>
                        </select>
        			</div>
                    
                    <?php osc_run_hook('user_register_form'); ?>
                    <script type="text/javascript">
                        var RecaptchaOptions = {
                            theme : 'clean'
                        };
                    </script>
                    <div class="inp-captcha">
                        <?php osc_show_recaptcha('register'); ?>
                    </div>
                    
        			<div class="c_reg-required">* <?php _e('This field is required', 'marketplace') ?></div>
        			<div class="c_reg-btn">
        				<button type="submit"><i class="mp mp-r"></i><?php _e('Create', 'marketplace') ?></button>
        			</div>
        		</form>
        	</div>
        </div>
    
        <?php osc_current_web_theme_path('footer.php'); ?>
    </body>
</html>