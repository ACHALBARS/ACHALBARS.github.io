<?php
/*
 * Copyright 2019 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this theme and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */

$sCountry = Params::getParam('sCountry');
$sRegion = Params::getParam('sRegion');
$sCity = Params::getParam('sCity');
$path = false;

if(OC_ADMIN) $path='admin';
?>
<!-- Search form all options -->
<form class="nocsrf form" action="<?php echo osc_base_url(true); ?>" method="post">
    <input type="hidden" name="page" value="search"/>
    
    <div class="c_maincat-box">
        <div class="c_select c_maincat-box__select">
    		<select id="sCategory" class="search-select" data-size="7" name="sCategory">
                <option value=""><?php echo osc_esc_html(__('Select a category...', 'marketplace'));?></option>
                <?php foreach(Category::newInstance()->toTree() as $category): ?>
    				<option value="<?php echo $category['pk_i_id']?>"><?php echo $category['s_name']?></option>
    				
                    <?php if(isset($category['categories']) && is_array($category['categories']) && osc_get_preference('subcategories', 'marketplace_theme'))
    				        CategoryForm::subcategory_select($category['categories'], null, __('Select a category...', 'marketplace'), 2);
    				?>
    			<?php endforeach; ?>
            </select>
    	</div>
        
        <?php $countries = Country::newInstance()->listAll(); ?>
        
        <?php if(count($countries)): ?>
            <div class="c_select c_maincat-box__select">
        		<select id="sCountry" class="search-select" data-size="7" name="sCountry">
                    <option value=""><?php echo osc_esc_html(__('Select a country...', 'marketplace'));?></option>
                    <?php foreach($countries as $country): ?>
        				<option value="<?php echo $country['pk_c_code']; ?>" <?php if(isset($sCountry) && $sCountry == $country['pk_c_code']) echo "selected"; ?>>
                            <?php echo $country['s_name']; ?>
                        </option>
        			<?php endforeach; ?>
                </select>
        	</div>
        <?php endif; ?>
        
        <?php if(count($countries)): ?>
            <?php if(isset($sRegion) || isset($sCountry)): ?>
                <?php $regions = Region::newInstance()->findByCountry($sCountry); ?>
                
                <div class="c_select c_maincat-box__select">
            		<select id="sRegion" class="search-select" data-size="7" name="sRegion" disabled>
                        <option value=""><?php echo osc_esc_html(__('Select a country first...', 'marketplace'));?></option>
                        <?php foreach($regions as $region): ?>
                            <option value="<?php echo $region['pk_i_id']; ?>" <?php if($sRegion == $region['pk_i_id']) echo "selected"; ?>>
                                <?php echo $region['s_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
            	</div>
            <?php endif; ?>
        <?php else: ?>
            <?php $regions = Region::newInstance()->listAll(); ?>
            <?php if(count($regions)): ?>
                <div class="c_select c_maincat-box__select">
            		<select id="sRegion" class="search-select" data-size="7" name="sRegion" disabled>
                        <option value=""><?php echo osc_esc_html(__('Select a country first...', 'marketplace'));?></option>
                        <?php foreach($regions as $region): ?>
                            <option value="<?php echo $region['pk_i_id']; ?>" <?php if(isset($sRegion) && $sRegion == $region['pk_i_id']) echo "selected"; ?>>
                                <?php echo $region['s_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
            	</div>
            <?php endif; ?>
        <?php endif; ?>
        
        <?php if(isset($sCity) || isset($sRegion)): ?>
            <?php $cities = City::newInstance()->findByRegion($sRegion); ?>
            
            <div class="c_select c_maincat-box__select">
        		<select id="sCity" class="search-select" data-size="7" name="sCity" disabled>
                    <option value=""><?php echo osc_esc_html(__('Select a region first...', 'marketplace'));?></option>
                    <?php foreach($cities as $city): ?>
                        <option value="<?php echo $city['pk_i_id']; ?>" <?php if($sCity == $city['pk_i_id']) echo "selected"; ?>>
                            <?php echo $city['s_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
        	</div>
        <?php endif; ?>
        
        <div class="c_maincat-box__select c_maincat-box__search">
    		<input id="sPattern" type="text" name="sPattern" placeholder="<?php echo osc_esc_html(__(osc_get_preference('keyword_placeholder', 'marketplace_theme'))); ?>">
    		<input type="submit" value="">
    	</div>
    </div>
</form>

<style>
.c_maincat-box__select {
    width: 19%;
    margin: 0;
}
</style>
<script>
$(document).ready(function() {    
    $("body").on("change","#sCountry",function() {
        var pk_c_code = $(this).val();
       
        <?php if($path=="admin"): ?>
            var url = '<?php echo osc_admin_base_url(true) . "?page=ajax&action=regions&countryId="; ?>' + pk_c_code;
        <?php else: ?>
            var url = '<?php echo osc_base_url(true) . "?page=ajax&action=regions&countryId="; ?>' + pk_c_code;
        <?php endif; ?>
        
        var result = '';
        
        if(pk_c_code != '') {
            $.ajax({
                type: "GET",
                url: url,
                dataType: 'json',
                success: function(data){
                    var length = data.length;
                    
                    if(length > 0) {
                        result += '<option selected value=""><?php _e('Select a region...', 'marketplace'); ?></option>';
                        
                        for(key in data) {
                            result += '<option value="' + data[key].pk_i_id + '">' + data[key].s_name + '</option>';
                        }
                    } 
                    else {
                        result += '<option selected value=""><?php _e('No regions found', 'marketplace') ?></option>';
                    }
                    
                    $("#sRegion").removeAttr('disabled').html(result).selectpicker('refresh');
                }
            });
        }
        else {
            $('#sRegion').prop('disabled', true).remove('option').html('<option><?php _e('Select a country first...', 'marketplace'); ?></option>').selectpicker('refresh');
            $('#sCity').prop('disabled', true).remove('option').html('<option><?php _e('Select a country first...', 'marketplace'); ?></option>').selectpicker('refresh');
        } 
    });
     
    $("body").on("change","#sRegion",function(){
        var pk_c_code = $(this).val();
        
        <?php if($path=="admin"): ?>
            var url = '<?php echo osc_admin_base_url(true)."?page=ajax&action=cities&regionId="; ?>' + pk_c_code;
        <?php else: ?>
            var url = '<?php echo osc_base_url(true)."?page=ajax&action=cities&regionId="; ?>' + pk_c_code;
        <?php endif; ?>
        
        var result = '';
        
        if(pk_c_code != '') {
            $.ajax({
                type: "GET",
                url: url,
                dataType: 'json',
                success: function(data){
                    var length = data.length;
                    
                    if(length > 0) {
                        result += '<option selected value=""><?php _e('Select a city...', 'marketplace'); ?></option>';
                        
                        for(key in data) {
                            result += '<option value="' + data[key].pk_i_id + '">' + data[key].s_name + '</option>';
                        }
                    } 
                    else {
                        result += '<option selected value=""><?php _e('No cities found', 'marketplace') ?></option>';
                    }
                    
                    $("#sCity").removeAttr('disabled').html(result).selectpicker('refresh');
                }
            });
        } 
        else {
            $('#sCity').prop('disabled', true).remove('option').html('<option><?php _e('Select a region first...', 'marketplace'); ?></option>').selectpicker('refresh');
        }
    });
});
 </script>