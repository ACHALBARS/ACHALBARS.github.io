document.addEventListener('DOMContentLoaded', function () {
	if (document.querySelectorAll('.form').length > 0) {
		const form = document.querySelectorAll('.form');
		form.forEach(formItem => {
			formItem.addEventListener('submit', formValid);
		});
	}
})

function formValid(e) {
	const thisForm = e.target;
	let error = formValidate(thisForm);
	e.preventDefault();
	if (error == 0) {
		/*form send script*/
	} 
}

function formValidate(thisForm) {

	let error = 0;
	let formReq = thisForm.querySelectorAll('._req');

	for (let index = 0; index < formReq.length; index++) {
		const input = formReq[index];
		formRemoveError(input);

		if (input.classList.contains('_email')) {
			if (!emailTest(input)) {
				formAddError(input);
				error++;
			}
		} else if (input.getAttribute("type") === "checkbox" && input.checked === false) {
			formAddError(input);
			error++;
		} else if (input.classList.contains('_name')) {
			if (input.value.length > 3 && input.value.length < 30) {
				if (document.querySelector('.sorry')) {
					document.querySelector('.sorry').remove();
				}
			} else {
				nameValid(input)
				formAddError(input);
				error++;
			}
		} else {
			if (input.value === '') {
				formAddError(input);
				error++;
			}
		}
	}
	return error;
}

function formAddError(input) {
	input.parentElement.classList.add('_error');
	input.classList.add('_error');
}

function formRemoveError(input) {
	input.parentElement.classList.remove('_error');
	input.classList.remove('_error');
}

function emailTest(input) {
	const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	let result = re.test(String(input.value).toLowerCase());
	return result;
}

function nameValid(input) {
	const nameParent = input.parentElement;
	if (!document.querySelector('.sorry')) {
		let div = document.createElement('div');
		div.className = "sorry";
		div.innerHTML = "<p>Sorry, your firstname must be bween 6 and 30</p>";
		nameParent.append(div);
	}
}

