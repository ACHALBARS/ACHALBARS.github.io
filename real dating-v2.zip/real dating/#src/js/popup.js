if ($('.modal-toggle').length) {
	$('.modal-toggle').on('click', function (e) {
		e.preventDefault();
		$('.modal').toggleClass('_open');
		$('body').toggleClass('_lock');
	});
}
