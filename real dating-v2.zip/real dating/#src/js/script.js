"use strict"

@@include('OS.js')
@@include('webp.js')
@@include('popup.js')
@@include('formsubmit.js')

if ($('.slider-girls').length) {
    $('.slider-girls').slick({
        arrows: true,
        autoHeight: true,
        slidesToShow: 6,
        infinite: false,
        autoplay: true,
        autoplaySpeed: 3000,
        pauseOnHover: true,
        pauseOnFocus: true,
        variableWidth: false,
        responsive: [
            {
                breakpoint: 1455,
                settings: {
                    slidesToShow: 4,
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,

                }
            },
            {
                breakpoint: 468,
                settings: {
                    slidesToShow: 2,
                }
            }
        ]
    });
}

if ($('.stories-slider').length) {
    $('.stories-slider').slick({
        arrows: true,
        autoHeight: true,
        slidesToShow: 2,
        infinite: false,
        variableWidth: true,
        responsive: [
            {
                breakpoint: 468,
                settings: "unslick"
            },

        ]
    });
}

